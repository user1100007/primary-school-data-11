# Security Specification: Form 11 & Form 12 Primary School Reports

## 1. Data Invariants
- Each report (Form 11 and Form 12) belongs to an authenticated user (`authorId == request.auth.uid`).
- A user can only create reports where `authorId == request.auth.uid`.
- A user can only read, update, or delete their own reports (`resource.data.authorId == request.auth.uid`).
- `academicYear` and `schoolName` are required string fields with size limits to prevent abuse.
- Report IDs must be valid alphanumeric identifier strings with length <= 128.
- Numeric indicators must be numbers >= 0.

## 2. The "Dirty Dozen" Threat Payloads (Must be Denied)
1. Unauthenticated user trying to read `/form11_reports/{reportId}`.
2. Unauthenticated user trying to create `/form11_reports/{reportId}`.
3. Authenticated user A trying to write `/form11_reports/{reportId}` with `authorId: 'userB'` (Identity Spoofing).
4. Authenticated user A trying to read a report created by user B (`resource.data.authorId != request.auth.uid`).
5. Authenticated user trying to update a report created by another user.
6. Payload with `academicYear` exceeding 50 characters (Resource Poisoning / Denial of Wallet).
7. Payload with `schoolName` exceeding 200 characters.
8. Injection of arbitrary keys or invalid document ID (e.g., 2000-character malicious path ID).
9. Updating `authorId` on an existing report to transfer ownership without authorization.
10. Unauthenticated user reading `/form12_reports/{reportId}`.
11. User creating `/form12_reports/{reportId}` without `authorId`.
12. User trying to write to non-existent collections or arbitrary documents (`/{document=**}`).
