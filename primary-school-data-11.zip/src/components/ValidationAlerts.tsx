import React from 'react';
import { FormAnalysis } from '../utils/validation';
import { toKhmerNumber } from '../utils/khmerNumerals';
import { 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  Info,
  Scale
} from 'lucide-react';

interface ValidationAlertsProps {
  analysis: FormAnalysis;
  useKhmerDigits: boolean;
}

export const ValidationAlerts: React.FC<ValidationAlertsProps> = ({
  analysis,
  useKhmerDigits,
}) => {
  const { isTotalBalanced, totalByGrades, totalByGender, issues } = analysis;

  const fmt = (n: number) => (useKhmerDigits ? toKhmerNumber(n) : n);

  const errors = issues.filter((i) => i.type === 'error');
  const warnings = issues.filter((i) => i.type === 'warning');
  const infos = issues.filter((i) => i.type === 'info');

  return (
    <div className="space-y-4 mb-6">
      {/* Student Balance Card */}
      <div
        className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
          isTotalBalanced
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
            : 'bg-red-50/80 border-red-300 text-red-900'
        }`}
      >
        <div className="flex items-start gap-3">
          <div
            className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
              isTotalBalanced ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
            }`}
          >
            {isTotalBalanced ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <Scale className="w-5 h-5" />
            )}
          </div>
          <div>
            <h3 className="font-bold text-sm">
              {isTotalBalanced
                ? 'តុល្យភាពចំនួនសិស្សសរុប៖ ត្រឹមត្រូវ និងស៊ីសង្វាក់គ្នា'
                : 'តុល្យភាពចំនួនសិស្សសរុប៖ មិនស៊ីសង្វាក់គ្នាទេ (សូមផ្ទៀងផ្ទាត់)'}
            </h3>
            <p className="text-xs mt-0.5 opacity-90">
              សរុបតាមកម្រិតថ្នាក់ (G1-3 + G4-6) = <span className="font-bold">{fmt(totalByGrades)}</span> នាក់ | 
              សរុបតាមភេទ (ប្រុស + ស្រី) = <span className="font-bold">{fmt(totalByGender)}</span> នាក់
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold shrink-0">
          <span className="px-3 py-1 rounded-md bg-white/80 border border-current shadow-2xs">
            G1-3 + G4-6: {fmt(totalByGrades)}
          </span>
          <span>=</span>
          <span className="px-3 py-1 rounded-md bg-white/80 border border-current shadow-2xs">
            ប្រុស + ស្រី: {fmt(totalByGender)}
          </span>
        </div>
      </div>

      {/* Issues list if any */}
      {issues.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-slate-600" />
            <span>កំណត់សម្គាល់ការផ្ទៀងផ្ទាត់ទិន្នន័យ ({fmt(issues.length)})</span>
          </h4>

          <div className="space-y-2">
            {errors.map((item, idx) => (
              <div
                key={`err-${idx}`}
                className="flex items-start gap-2.5 p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-900 text-xs"
              >
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <span className="font-semibold">[កំហុស]</span> {item.message}
                  {item.relatedIndicators && (
                    <span className="ml-1 text-red-700 font-medium">
                      (ពាក់ព័ន្ធសូចនាករ: {item.relatedIndicators.map((id) => `#${fmt(id)}`).join(', ')})
                    </span>
                  )}
                </div>
              </div>
            ))}

            {warnings.map((item, idx) => (
              <div
                key={`warn-${idx}`}
                className="flex items-start gap-2.5 p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs"
              >
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <span className="font-semibold">[ការព្រមាន]</span> {item.message}
                  {item.relatedIndicators && (
                    <span className="ml-1 text-amber-700 font-medium">
                      (ពាក់ព័ន្ធសូចនាករ: {item.relatedIndicators.map((id) => `#${fmt(id)}`).join(', ')})
                    </span>
                  )}
                </div>
              </div>
            ))}

            {infos.map((item, idx) => (
              <div
                key={`info-${idx}`}
                className="flex items-start gap-2.5 p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-blue-900 text-xs"
              >
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <span className="font-semibold">[ព័ត៌មាន]</span> {item.message}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
