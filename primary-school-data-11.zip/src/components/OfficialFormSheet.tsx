import React from 'react';
import { Form11Data, IndicatorKey } from '../types/form11';
import { INDICATORS } from '../data/initialData';
import { toKhmerNumber, fromKhmerNumber } from '../utils/khmerNumerals';

interface OfficialFormSheetProps {
  data: Form11Data;
  onChange: (key: IndicatorKey, value: number | 'yes' | 'no' | '') => void;
  onMetaChange: (field: keyof Form11Data['metadata'], value: string) => void;
  useKhmerDigits: boolean;
  relatedIssuesMap: Record<number, string[]>;
}

export const OfficialFormSheet: React.FC<OfficialFormSheetProps> = ({
  data,
  onChange,
  onMetaChange,
  useKhmerDigits,
  relatedIssuesMap,
}) => {
  const meta = data.metadata;

  const handleNumberInput = (key: IndicatorKey, rawValue: string) => {
    const converted = fromKhmerNumber(rawValue);
    if (converted === '') {
      onChange(key, '');
      return;
    }
    const num = parseInt(converted, 10);
    if (!isNaN(num) && num >= 0) {
      onChange(key, num);
    }
  };

  const getDisplayVal = (key: IndicatorKey, type: 'number' | 'boolean') => {
    const val = data[key];
    if (val === '' || val === undefined || val === null) return '';
    if (type === 'boolean') {
      return val === 'yes' ? 'បាទ/ចាស' : 'ទេ';
    }
    return useKhmerDigits ? toKhmerNumber(val) : val.toString();
  };

  return (
    <div className="w-full max-w-[850px] mx-auto bg-white text-black p-6 sm:p-10 shadow-lg rounded-sm border border-slate-300 print:shadow-none print:border-none print:p-0 print:max-w-none">
      
      {/* Top Header Section */}
      <div className="flex justify-between items-start mb-2">
        {/* Left: Titles & School Inputs */}
        <div className="flex-1 max-w-[560px]">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-black mb-3">
            ទិន្នន័យសាលាបឋមសិក្សា
          </h1>

          {/* School Name Row */}
          <div className="flex items-center gap-3 mb-2">
            <span className="text-sm sm:text-base font-bold whitespace-nowrap text-slate-900 w-36">
              ឈ្មោះសាលាបឋមសិក្សា
            </span>
            <input
              type="text"
              value={meta.schoolName}
              onChange={(e) => onMetaChange('schoolName', e.target.value)}
              placeholder=""
              className="w-56 sm:w-64 h-8 px-2 border border-black rounded-none text-sm font-semibold text-black bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-600 print:border-black"
            />
          </div>

          {/* Report Year Row */}
          <div className="flex items-center gap-3 mb-3">
            <span className="text-sm sm:text-base font-bold whitespace-nowrap text-slate-900 w-36">
              របាយការណ៍ប្រចាំឆ្នាំ
            </span>
            <input
              type="text"
              value={meta.academicYear}
              onChange={(e) => onMetaChange('academicYear', e.target.value)}
              placeholder=""
              className="w-56 sm:w-64 h-8 px-2 border border-black rounded-none text-sm font-semibold text-black bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-600 print:border-black"
            />
          </div>
        </div>

        {/* Right: Form 11 Title */}
        <div className="text-right">
          <div className="text-xl sm:text-2xl font-bold tracking-tight text-black">
            ទម្រង់ទី១១
          </div>
        </div>
      </div>

      {/* Instruction Note */}
      <div className="text-[11px] sm:text-xs leading-relaxed text-slate-900 italic mb-3">
        <span className="font-bold not-italic">ការណែនាំ៖</span> ទិន្នន័យនេះបំពេញដោយនាយក ឬនាយិកាសាលា។ សូមបំពេញនៅក្នុងប្រអប់នីមួយៗ បន្ទាប់មកផ្ទៀងផ្ទាត់ភាពត្រឹមត្រូវនៃទិន្នន័យ និងចុះហត្ថលេខាជាផ្លូវការដោយនាយកសាលា និងប្រគល់ទៅការិយាល័យអប់រំ យុវជន និងកីឡាក្រុង ស្រុក ខណ្ឌ។ សូមកុំភ្លេចបំពេញឈ្មោះសាលា និងឆ្នាំទិន្នន័យ (ឧ. ចំពោះឆ្នាំសិក្សា ២០២៤-២០២៥ សូមបំពេញ២០២៥បានហើយ)។
      </div>

      {/* Table Header */}
      <div className="border-t border-b-2 border-black py-1.5 flex items-center text-xs sm:text-sm font-bold text-black">
        <div className="w-8 sm:w-10 text-center shrink-0">#</div>
        <div className="flex-1 pr-3 pl-1">សូចនាករ</div>
        <div className="w-20 sm:w-24 shrink-0 text-center"></div>
        <div className="w-64 sm:w-80 shrink-0 pl-2">សេចក្តីណែនាំ</div>
      </div>

      {/* Table 23 Indicators Rows */}
      <div className="divide-y divide-slate-400 border-b-2 border-black">
        {INDICATORS.map((ind) => {
          const val = data[ind.key];
          const issues = relatedIssuesMap[ind.id] || [];
          const hasError = issues.some((m) => m.includes('មិនត្រូវគ្នា') || m.includes('លើសពី') || m.includes('មិនអាច'));

          return (
            <div
              key={ind.id}
              className={`flex items-center py-1 text-xs sm:text-[13px] leading-tight ${
                hasError ? 'bg-red-50/50 print:bg-transparent' : ''
              }`}
            >
              {/* ID # */}
              <div className="w-8 sm:w-10 text-center font-bold text-black shrink-0 self-center">
                {useKhmerDigits ? toKhmerNumber(ind.id) : ind.id}
              </div>

              {/* Indicator Name */}
              <div className="flex-1 pr-3 pl-1 text-black leading-snug">
                {ind.name}
              </div>

              {/* Input Box [   ] */}
              <div className="w-20 sm:w-24 shrink-0 flex justify-center items-center py-0.5">
                {ind.type === 'number' ? (
                  <div className="relative group">
                    <input
                      type="text"
                      inputMode="numeric"
                      value={getDisplayVal(ind.key, 'number')}
                      onChange={(e) => handleNumberInput(ind.key, e.target.value)}
                      placeholder=""
                      className={`w-16 sm:w-20 h-7 text-center font-bold text-sm text-black border rounded-none focus:outline-none focus:ring-1 focus:ring-blue-600 print:border-black ${
                        hasError
                          ? 'border-red-500 bg-red-50/40 print:border-black print:bg-transparent'
                          : 'border-black bg-white'
                      }`}
                    />
                    {issues.length > 0 && (
                      <div className="no-print hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-1 z-20 w-48 p-1.5 bg-slate-900 text-white text-[10px] rounded shadow-lg pointer-events-none text-center">
                        {issues[0]}
                      </div>
                    )}
                  </div>
                ) : (
                  /* Boolean Toggle Box */
                  <button
                    type="button"
                    onClick={() => {
                      const next = val === 'yes' ? 'no' : val === 'no' ? '' : 'yes';
                      onChange(ind.key, next as 'yes' | 'no' | '');
                    }}
                    title="ចុចដើម្បីប្តូរ៖ បាទ/ចាស ឬ ទេ"
                    className="w-16 sm:w-20 h-7 border border-black rounded-none flex items-center justify-center font-bold text-xs text-black bg-white hover:bg-slate-50 transition-colors cursor-pointer print:border-black"
                  >
                    {val === 'yes' ? 'បាទ/ចាស' : val === 'no' ? 'ទេ' : ''}
                  </button>
                )}
              </div>

              {/* Instruction Note in Bordered Box */}
              <div className="w-64 sm:w-80 shrink-0 pl-2">
                {ind.instruction ? (
                  <div className="border border-slate-700 rounded px-2 py-1 text-[10px] sm:text-[11px] text-slate-900 leading-tight">
                    {ind.instruction}
                  </div>
                ) : (
                  <div className="h-6"></div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Responsibility Statement */}
      <div className="mt-3 font-bold text-xs sm:text-[13px] text-black">
        ការទទួលខុសត្រូវ៖ ទិន្នន័យនេះផ្តល់ដោយនាយកសាលា និងបានពិនិត្យផ្ទៀងផ្ទាត់ដោយការិយាល័យអប់រំ យុវជន និងកីឡា ក្រុង ស្រុក ខណ្ឌ
      </div>

      {/* Signatures & Certification Area */}
      <div className="mt-6 space-y-8 text-xs sm:text-[13px] text-black">
        
        {/* Row 1: School Principal */}
        <div className="flex items-start justify-between">
          <div className="w-56 sm:w-64 leading-tight font-medium">
            <div>សូមបញ្ជាក់ថា ទិន្នន័យដែលបានផ្តល់ជូននេះពិតជា</div>
            <div>ត្រឹមត្រូវ និងពេញលេញ</div>
          </div>

          <div className="w-56 sm:w-64 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.principalName}
                onChange={(e) => onMetaChange('principalName', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs font-bold bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              ហត្ថលេខា និងត្រានាយកសាលា
            </div>
          </div>

          <div className="w-44 sm:w-48 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.reportDate}
                onChange={(e) => onMetaChange('reportDate', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              កាលបរិច្ឆេទ
            </div>
          </div>
        </div>

        {/* Row 2: District Office */}
        <div className="flex items-start justify-between pt-2">
          <div className="w-56 sm:w-64 leading-tight font-medium">
            <div>បានពិនិត្យ និងសូមបញ្ជាក់ថា ទិន្នន័យនេះពិតជាត្រឹមត្រូវ</div>
            <div>អាចបញ្ចូលក្នុងប្រព័ន្ធបាន</div>
          </div>

          <div className="w-56 sm:w-64 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.districtOfficerName || ''}
                onChange={(e) => onMetaChange('districtOfficerName', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs font-bold bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px] leading-tight">
              <div>ហត្ថលេខា ការិយាល័យអប់រំ យុវជន</div>
              <div>និងកីឡាក្រុង ស្រុក ខណ្ឌ</div>
            </div>
          </div>

          <div className="w-44 sm:w-48 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.verificationDate || ''}
                onChange={(e) => onMetaChange('verificationDate', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              កាលបរិច្ឆេទ
            </div>
          </div>
        </div>

      </div>

      {/* Production Timestamp at bottom right */}
      <div className="mt-8 text-right text-[11px] sm:text-xs text-slate-800 italic">
        កាលបរិច្ឆេទផលិត៖ 2026-10-26 15:08
      </div>

    </div>
  );
};
