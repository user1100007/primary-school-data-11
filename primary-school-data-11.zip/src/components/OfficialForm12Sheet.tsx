import React from 'react';
import { Form12Data, Form12Key } from '../types/form12';
import { FORM12_INCOME_ITEMS, FORM12_EXPENSE_ITEMS } from '../data/form12Data';
import { toKhmerNumber, fromKhmerNumber } from '../utils/khmerNumerals';

interface OfficialForm12SheetProps {
  data: Form12Data;
  onChange: (key: Form12Key, value: number | '') => void;
  onMetaChange: (field: keyof Form12Data['metadata'], value: string) => void;
  useKhmerDigits: boolean;
}

export const OfficialForm12Sheet: React.FC<OfficialForm12SheetProps> = ({
  data,
  onChange,
  onMetaChange,
  useKhmerDigits,
}) => {
  const meta = data.metadata;

  const handleNumberInput = (key: Form12Key, rawValue: string) => {
    const converted = fromKhmerNumber(rawValue.replace(/,/g, ''));
    if (converted === '') {
      onChange(key, '');
      return;
    }
    const num = parseInt(converted, 10);
    if (!isNaN(num) && num >= 0) {
      onChange(key, num);
    }
  };

  const getDisplayVal = (key: Form12Key) => {
    const val = data[key];
    if (val === '' || val === undefined || val === null) return '';
    const formatted = val.toLocaleString();
    return useKhmerDigits ? toKhmerNumber(formatted) : formatted;
  };

  const n = (v: number | '') => (typeof v === 'number' ? v : 0);
  const totalIncome = n(data.income1) + n(data.income2) + n(data.income3) + n(data.income4);
  const totalExpense = n(data.expense5) + n(data.expense6) + n(data.expense7);
  const netBalance = totalIncome - totalExpense;

  const fmtTotal = (val: number) => {
    const formatted = val.toLocaleString();
    return useKhmerDigits ? toKhmerNumber(formatted) : formatted;
  };

  return (
    <div className="w-full max-w-[850px] mx-auto bg-white text-black p-6 sm:p-10 shadow-lg rounded-sm border border-slate-300 print:shadow-none print:border-none print:p-0 print:max-w-none">
      
      {/* Top Header Section */}
      <div className="flex justify-between items-start mb-2">
        {/* Left: Titles & School Inputs */}
        <div className="flex-1 max-w-[560px]">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-black mb-3">
            ហិរញ្ញវត្ថុសាលាបឋមសិក្សា
          </h1>

          {/* School Name Row */}
          <div className="flex items-center gap-3 mb-2">
            <span className="text-sm sm:text-base font-bold whitespace-nowrap text-slate-900 w-36">
              ឈ្មោះសាលាបឋមសិក្សា
            </span>
            <input
              type="text"
              value={meta.schoolName}
              onChange={(e) => onMetaChange('schoolName', e.target.value)}
              placeholder=""
              className="w-56 sm:w-64 h-8 px-2 border border-black rounded-none text-sm font-semibold text-black bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-600 print:border-black"
            />
          </div>

          {/* Report Year Row */}
          <div className="flex items-center gap-3 mb-3">
            <span className="text-sm sm:text-base font-bold whitespace-nowrap text-slate-900 w-36">
              របាយការណ៍ប្រចាំឆ្នាំ
            </span>
            <input
              type="text"
              value={meta.academicYear}
              onChange={(e) => onMetaChange('academicYear', e.target.value)}
              placeholder=""
              className="w-56 sm:w-64 h-8 px-2 border border-black rounded-none text-sm font-semibold text-black bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-600 print:border-black"
            />
          </div>
        </div>

        {/* Right: Form 12 Title */}
        <div className="text-right">
          <div className="text-xl sm:text-2xl font-bold tracking-tight text-black">
            ទម្រង់ទី១២
          </div>
        </div>
      </div>

      {/* Instruction Note */}
      <div className="text-[11px] sm:text-xs leading-relaxed text-slate-900 italic mb-4">
        <span className="font-bold not-italic">ការណែនាំ៖</span> ទិន្នន័យនេះបំពេញដោយនាយក ឬនាយិកាសាលា។ សូមបំពេញនៅក្នុងប្រអប់នីមួយៗ បន្ទាប់មកផ្ទៀងផ្ទាត់ភាពត្រឹមត្រូវនៃទិន្នន័យ និងចុះហត្ថលេខាបោះត្រាដោយនាយកសាលា និងប្រគល់ទៅការិយាល័យអប់រំ យុវជន និងកីឡាក្រុង ស្រុក ខណ្ឌ។ សូមកុំភ្លេចបំពេញឈ្មោះសាលា និងឆ្នាំទិន្នន័យ (ឧ. ចំពោះឆ្នាំសិក្សា ២០២៤-២០២៥ សូមបំពេញតែ២០២៥បានហើយ)។
      </div>

      {/* SECTION 1: ចំណូល (Income) */}
      <div className="mb-4">
        <div className="font-bold text-sm sm:text-base text-black mb-1">
          ចំណូល
        </div>

        {/* Income Table Header */}
        <div className="border-t border-b-2 border-black py-1.5 flex items-center text-xs sm:text-sm font-bold text-black">
          <div className="w-8 sm:w-10 text-center shrink-0">#</div>
          <div className="flex-1 pr-3 pl-1">បរិយាយ</div>
          <div className="w-28 sm:w-36 shrink-0 text-center">ជាក់ស្ដែង</div>
          <div className="w-64 sm:w-80 shrink-0 pl-2">ពិពណ៌នា</div>
        </div>

        {/* Income Items Rows */}
        <div className="divide-y divide-slate-400 border-b-2 border-black">
          {FORM12_INCOME_ITEMS.map((item) => (
            <div
              key={item.id}
              className="flex items-center py-1.5 text-xs sm:text-[13px] leading-tight"
            >
              {/* ID # */}
              <div className="w-8 sm:w-10 text-center font-bold text-black shrink-0 self-center">
                {useKhmerDigits ? toKhmerNumber(item.id) : item.id}
              </div>

              {/* Name */}
              <div className="flex-1 pr-3 pl-1 font-semibold text-black leading-snug">
                {item.name}
              </div>

              {/* Input Box [   ] */}
              <div className="w-28 sm:w-36 shrink-0 flex justify-center items-center py-0.5">
                <input
                  type="text"
                  inputMode="numeric"
                  value={getDisplayVal(item.key)}
                  onChange={(e) => handleNumberInput(item.key, e.target.value)}
                  placeholder=""
                  className="w-24 sm:w-28 h-7 text-center font-bold text-sm text-black border border-black rounded-none focus:outline-none focus:ring-1 focus:ring-blue-600 bg-white print:border-black"
                />
              </div>

              {/* Description */}
              <div className="w-64 sm:w-80 shrink-0 pl-2 text-[10px] sm:text-[11px] text-slate-900 leading-tight">
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: ចំណាយ (Expenditure) */}
      <div className="mb-4">
        <div className="font-bold text-sm sm:text-base text-black mb-1">
          ចំណាយ
        </div>

        {/* Expense Table Header */}
        <div className="border-t border-b-2 border-black py-1.5 flex items-center text-xs sm:text-sm font-bold text-black">
          <div className="w-8 sm:w-10 text-center shrink-0">#</div>
          <div className="flex-1 pr-3 pl-1">បរិយាយ</div>
          <div className="w-28 sm:w-36 shrink-0 text-center">ជាក់ស្ដែង</div>
          <div className="w-64 sm:w-80 shrink-0 pl-2">ពិពណ៌នា</div>
        </div>

        {/* Expense Items Rows */}
        <div className="divide-y divide-slate-400 border-b-2 border-black">
          {FORM12_EXPENSE_ITEMS.map((item) => (
            <div
              key={item.id}
              className="flex items-center py-1.5 text-xs sm:text-[13px] leading-tight"
            >
              {/* ID # */}
              <div className="w-8 sm:w-10 text-center font-bold text-black shrink-0 self-center">
                {useKhmerDigits ? toKhmerNumber(item.id) : item.id}
              </div>

              {/* Name */}
              <div className="flex-1 pr-3 pl-1 font-semibold text-black leading-snug">
                {item.name}
              </div>

              {/* Input Box [   ] */}
              <div className="w-28 sm:w-36 shrink-0 flex justify-center items-center py-0.5">
                <input
                  type="text"
                  inputMode="numeric"
                  value={getDisplayVal(item.key)}
                  onChange={(e) => handleNumberInput(item.key, e.target.value)}
                  placeholder=""
                  className="w-24 sm:w-28 h-7 text-center font-bold text-sm text-black border border-black rounded-none focus:outline-none focus:ring-1 focus:ring-blue-600 bg-white print:border-black"
                />
              </div>

              {/* Description */}
              <div className="w-64 sm:w-80 shrink-0 pl-2 text-[10px] sm:text-[11px] text-slate-900 leading-tight">
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Screen-Only Financial Quick Summary */}
      <div className="no-print my-3 p-3 bg-slate-50 border border-slate-200 rounded text-xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-4">
          <div>
            <span className="text-slate-500">ចំណូលសរុប: </span>
            <span className="font-bold text-emerald-700">{fmtTotal(totalIncome)} រៀល</span>
          </div>
          <div>
            <span className="text-slate-500">ចំណាយសរុប: </span>
            <span className="font-bold text-red-700">{fmtTotal(totalExpense)} រៀល</span>
          </div>
        </div>
        <div>
          <span className="text-slate-500">សមតុល្យសល់: </span>
          <span className={`font-bold ${netBalance >= 0 ? 'text-blue-700' : 'text-red-600'}`}>
            {fmtTotal(netBalance)} រៀល
          </span>
        </div>
      </div>

      {/* Responsibility Statement */}
      <div className="mt-3 font-bold text-xs sm:text-[13px] text-black">
        ការទទួលខុសត្រូវ៖ ទិន្នន័យនេះផ្តល់ដោយនាយកសាលា និងបានពិនិត្យផ្ទៀងផ្ទាត់ដោយការិយាល័យអប់រំ យុវជន និងកីឡា ក្រុង ស្រុក ខណ្ឌ
      </div>

      {/* Signatures & Certification Area */}
      <div className="mt-6 space-y-8 text-xs sm:text-[13px] text-black">
        
        {/* Row 1: School Principal */}
        <div className="flex items-start justify-between">
          <div className="w-56 sm:w-64 leading-tight font-medium">
            <div>សូមបញ្ជាក់ថា ទិន្នន័យដែលបានផ្តល់ជូននេះពិតជា</div>
            <div>ត្រឹមត្រូវ និងពេញលេញ</div>
          </div>

          <div className="w-56 sm:w-64 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.principalName}
                onChange={(e) => onMetaChange('principalName', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs font-bold bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              ហត្ថលេខា និងត្រានាយកសាលា
            </div>
          </div>

          <div className="w-44 sm:w-48 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.reportDate}
                onChange={(e) => onMetaChange('reportDate', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              កាលបរិច្ឆេទ
            </div>
          </div>
        </div>

        {/* Row 2: District Office */}
        <div className="flex items-start justify-between pt-2">
          <div className="w-56 sm:w-64 leading-tight font-medium">
            <div>បានពិនិត្យ និងសូមបញ្ជាក់ថា ទិន្នន័យនេះពិតជាត្រឹមត្រូវ</div>
            <div>អាចបញ្ចូលក្នុងប្រព័ន្ធបាន</div>
          </div>

          <div className="w-56 sm:w-64 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.districtOfficerName || ''}
                onChange={(e) => onMetaChange('districtOfficerName', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs font-bold bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px] leading-tight">
              <div>ហត្ថលេខា ការិយាល័យអប់រំ យុវជន</div>
              <div>និងកីឡាក្រុង ស្រុក ខណ្ឌ</div>
            </div>
          </div>

          <div className="w-44 sm:w-48 text-center">
            <div className="border-b border-dashed border-black mb-1.5 min-h-[22px] flex items-center justify-center">
              <input
                type="text"
                value={meta.verificationDate || ''}
                onChange={(e) => onMetaChange('verificationDate', e.target.value)}
                placeholder=""
                className="w-full text-center text-xs bg-transparent border-none focus:outline-none"
              />
            </div>
            <div className="font-semibold text-slate-900 text-xs sm:text-[12px]">
              កាលបរិច្ឆេទ
            </div>
          </div>
        </div>

      </div>

      {/* Production Timestamp at bottom right */}
      <div className="mt-8 text-right text-[11px] sm:text-xs text-slate-800 italic">
        កាលបរិច្ឆេទផលិត៖ 2026-10-26 14:39
      </div>

    </div>
  );
};
