import React, { useState } from 'react';
import { 
  Cloud, 
  CloudCheck, 
  Calendar, 
  Plus, 
  LogIn, 
  LogOut, 
  RotateCw,
  FolderOpen
} from 'lucide-react';
import { User } from 'firebase/auth';
import { YearReportSummary } from '../firebase/reportsService';

interface YearSelectorBarProps {
  currentYear: string;
  onSelectYear: (year: string) => void;
  availableYears: YearReportSummary[];
  onAddNewYear: (newYear: string) => void;
  onSaveToCloud: () => void;
  isSaving: boolean;
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
  lastSavedAt: string | null;
}

export const YearSelectorBar: React.FC<YearSelectorBarProps> = ({
  currentYear,
  onSelectYear,
  availableYears,
  onAddNewYear,
  onSaveToCloud,
  isSaving,
  user,
  onLogin,
  onLogout,
  lastSavedAt,
}) => {
  const [showNewYearModal, setShowNewYearModal] = useState(false);
  const [newYearInput, setNewYearInput] = useState('');

  const handleCreateYear = () => {
    if (!newYearInput.trim()) return;
    onAddNewYear(newYearInput.trim());
    setNewYearInput('');
    setShowNewYearModal(false);
  };

  return (
    <div className="bg-white border-b border-slate-200 px-4 py-2.5 shadow-2xs no-print">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Left: Year Selector & New Year Button */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 font-bold text-slate-700">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>ឆ្នាំសិក្សា / របាយការណ៍៖</span>
          </div>

          {/* Academic Year Selector */}
          <div className="relative">
            <select
              value={currentYear}
              onChange={(e) => onSelectYear(e.target.value)}
              className="bg-slate-50 border border-slate-300 font-bold text-slate-900 rounded-lg px-2.5 py-1.5 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-600 text-xs"
            >
              {availableYears.length > 0 ? (
                availableYears.map((y) => (
                  <option key={y.academicYear} value={y.academicYear}>
                    ឆ្នាំ {y.academicYear} {y.hasForm11 && y.hasForm12 ? '(ទ១១ & ទ១២)' : y.hasForm11 ? '(ទ១១)' : '(ទ១២)'}
                  </option>
                ))
              ) : (
                <option value={currentYear}>ឆ្នាំ {currentYear}</option>
              )}
            </select>
          </div>

          {/* Add New Year Button */}
          <button
            type="button"
            onClick={() => setShowNewYearModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium rounded-lg transition-colors border border-slate-200"
            title="បន្ថែមឆ្នាំសិក្សាថ្មី"
          >
            <Plus className="w-3.5 h-3.5 text-blue-600" />
            <span>បន្ថែមឆ្នាំថ្មី</span>
          </button>

          {/* Cloud Save status indicator */}
          {lastSavedAt && (
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              បានរក្សាទុក៖ {lastSavedAt}
            </span>
          )}
        </div>

        {/* Right: Cloud Sync Actions & Auth */}
        <div className="flex items-center gap-2">
          
          {/* Save to Firestore Button */}
          <button
            type="button"
            onClick={onSaveToCloud}
            disabled={isSaving}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-white shadow-xs transition-colors ${
              isSaving
                ? 'bg-blue-400 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {isSaving ? (
              <RotateCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Cloud className="w-3.5 h-3.5" />
            )}
            <span>{isSaving ? 'កំពុងរក្សាទុក...' : 'រក្សាទុកលើ Cloud Firestore'}</span>
          </button>

          {/* User Sign In / Profile */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              {user.photoURL && (
                <img
                  src={user.photoURL}
                  alt={user.displayName || ''}
                  className="w-6 h-6 rounded-full border border-slate-300"
                />
              )}
              <span className="font-semibold text-slate-800 max-w-[120px] truncate hidden md:inline">
                {user.displayName || user.email}
              </span>
              <button
                type="button"
                onClick={onLogout}
                className="p-1.5 text-slate-400 hover:text-red-600 rounded-md transition-colors"
                title="ចាកចេញ (Sign Out)"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onLogin}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 rounded-lg font-medium transition-colors"
              title="ចូលគណនីដើម្បីផ្ទុកទិន្នន័យលើ Firestore"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>ចូលគណនី Google</span>
            </button>
          )}

        </div>

      </div>

      {/* Modal for adding a new academic year */}
      {showNewYearModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-5 text-slate-800 animate-in fade-in">
            <h3 className="font-bold text-base mb-1 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-600" />
              <span>បង្កើតឆ្នាំសិក្សាថ្មី</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              សូមបញ្ចូលកាលបរិច្ឆេទឆ្នាំសិក្សា (ឧទាហរណ៍៖ ២០២៥, ២០២៦ ឬ ២០២៥-២០២៦)
            </p>

            <input
              type="text"
              value={newYearInput}
              onChange={(e) => setNewYearInput(e.target.value)}
              placeholder="ឧ. ២០២៦-២០២៧ ឬ ២០២៧"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-blue-600 font-bold"
              autoFocus
            />

            <div className="flex justify-end gap-2 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setShowNewYearModal(false)}
                className="px-3 py-2 rounded-lg text-slate-600 hover:bg-slate-100"
              >
                បោះបង់
              </button>
              <button
                type="button"
                onClick={handleCreateYear}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                យល់ព្រម
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
