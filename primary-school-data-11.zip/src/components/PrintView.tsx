import React from 'react';
import { Form11Data, IndicatorKey } from '../types/form11';
import { INDICATORS } from '../data/initialData';
import { toKhmerNumber, formatKhmerDate } from '../utils/khmerNumerals';

interface PrintViewProps {
  data: Form11Data;
  useKhmerDigits: boolean;
}

export const PrintView: React.FC<PrintViewProps> = ({ data, useKhmerDigits }) => {
  const meta = data.metadata;

  const fmtVal = (key: IndicatorKey, type: string) => {
    const val = data[key];
    if (val === '' || val === undefined || val === null) return '';
    if (type === 'boolean') {
      return val === 'yes' ? 'បាទ/ចាស' : 'ទេ';
    }
    return useKhmerDigits ? toKhmerNumber(val) : val.toString();
  };

  return (
    <div className="bg-white p-6 sm:p-10 max-w-[210mm] mx-auto text-black border border-slate-300 print:border-none shadow-sm print:shadow-none card-print">
      
      {/* Official MoEYS Cambodia Header */}
      <div className="flex justify-between items-start mb-6">
        {/* Left side: Ministry & Department */}
        <div className="text-center sm:text-left text-sm leading-relaxed">
          <div className="font-moul text-xs sm:text-sm">
            ក្រសួងអប់រំ យុវជន និងកីឡា
          </div>
          <div className="font-medium text-xs text-slate-800">
            មន្ទីរអប់រំ យុវជន និងកីឡា ខេត្ត/រាជធានី៖ <span className="font-bold border-b border-dotted border-black px-2">{meta.province || '........................'}</span>
          </div>
          <div className="font-medium text-xs text-slate-800">
            ការិយាល័យអប់រំ យុវជន និងកីឡា ស្រុក/ខណ្ឌ៖ <span className="font-bold border-b border-dotted border-black px-2">{meta.district || '........................'}</span>
          </div>
          <div className="font-medium text-xs text-slate-800">
            សាលាបឋមសិក្សា៖ <span className="font-bold border-b border-dotted border-black px-2">{meta.schoolName || '...........................................'}</span>
          </div>
          {meta.schoolCode && (
            <div className="text-[11px] text-slate-600">
              កូដសាលា៖ <span className="font-semibold">{meta.schoolCode}</span>
            </div>
          )}
        </div>

        {/* Right side: Kingdom Motto */}
        <div className="text-center text-xs leading-relaxed">
          <div className="font-moul text-xs sm:text-sm">
            ព្រះរាជាណាចក្រកម្ពុជា
          </div>
          <div className="font-semibold text-xs text-slate-800">
            ជាតិ សាសនា ព្រះមហាក្សត្រ
          </div>
          <div className="text-xs text-slate-400 tracking-widest mt-1">
            ⚜ ⚜ ⚜
          </div>
        </div>
      </div>

      {/* Document Main Title */}
      <div className="text-center my-6">
        <h1 className="font-moul text-base sm:text-lg text-black mb-1">
          ទិន្នន័យសាលាបឋមសិក្សា
        </h1>
        <div className="text-sm font-semibold text-slate-800">
          ឈ្មោះសាលាបឋមសិក្សា៖ <span className="font-bold underline decoration-slate-400 px-2">{meta.schoolName || '...................................................'}</span>
        </div>
        <div className="text-xs text-slate-700 mt-1">
          រាយការណ៍ប្រចាំឆ្នាំ • ឆ្នាំសិក្សា៖ <span className="font-bold underline px-2">{meta.academicYear || '...................'}</span>
        </div>
        <div className="inline-block mt-2 px-4 py-1 border-2 border-black font-moul text-xs uppercase tracking-wider">
          ទម្រង់ទី១១
        </div>
      </div>

      {/* Official Guideline Note */}
      <div className="p-3 mb-4 border border-slate-400 bg-slate-50 text-[11px] leading-relaxed text-slate-800 rounded">
        <span className="font-bold">ការណែនាំ៖</span> ទិន្នន័យនេះបំពេញដោយនាយក ឬនាយិកាសាលា។ សូមបំពេញក្នុងប្រអប់នីមួយៗ បន្ទាប់មកផ្ទៀងផ្ទាត់ភាពត្រឹមត្រូវនៃទិន្នន័យ និងចុះហត្ថលេខាជាផ្លូវការដោយនាយកសាលា និងប្រគល់ទៅការិយាល័យអប់រំ យុវជន និងកីឡា ស្រុក ខណ្ឌ។ សូមកុំភ្លេចបំពេញឈ្មោះសាលា និងកំរិតឆ្នាំ (ឧ. ចំពោះឆ្នាំសិក្សា ២០២៤-២០២៥ សូមបំពេញ២០២៥បានហើយ)។
      </div>

      {/* Official Form Table */}
      <table className="w-full border-collapse border border-black text-xs mb-6">
        <thead>
          <tr className="bg-slate-100 font-bold border-b border-black text-center">
            <th className="border border-black p-2 w-10">#</th>
            <th className="border border-black p-2 text-left">សូចនាករ</th>
            <th className="border border-black p-2 text-left w-2/5">សេចក្តីណែនាំ</th>
            <th className="border border-black p-2 w-24 text-center">ទិន្នន័យ</th>
          </tr>
        </thead>
        <tbody>
          {INDICATORS.map((ind) => (
            <tr key={ind.id} className="border-b border-black">
              <td className="border border-black p-1.5 text-center font-bold">
                {useKhmerDigits ? toKhmerNumber(ind.id) : ind.id}
              </td>
              <td className="border border-black p-1.5 font-medium leading-snug">
                {ind.name}
              </td>
              <td className="border border-black p-1.5 text-[11px] text-slate-700 leading-tight">
                {ind.instruction || '-'}
              </td>
              <td className="border border-black p-1.5 text-center font-bold text-sm bg-slate-50/50">
                {fmtVal(ind.key, ind.type)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Responsibility Statement */}
      <div className="text-xs leading-relaxed text-slate-800 mb-6 italic">
        <p className="font-semibold not-italic">
          ការទទួលខុសត្រូវ៖ ទិន្នន័យនេះផ្តល់ដោយនាយកសាលា និងបានពិនិត្យផ្ទៀងផ្ទាត់ដោយការិយាល័យអប់រំ យុវជន និងកីឡា ស្រុក ខណ្ឌ
        </p>
        <p className="mt-1">
          សូមបញ្ជាក់ថា ទិន្នន័យដែលបានផ្តល់នេះពិតជាត្រឹមត្រូវ និងពេញលេញ
        </p>
      </div>

      {/* Signatures & Certification Grid */}
      <div className="grid grid-cols-2 gap-8 text-xs pt-4 border-t border-slate-300">
        
        {/* Principal Side */}
        <div className="text-center flex flex-col justify-between h-48">
          <div>
            <div className="text-slate-600 mb-1">
              {meta.reportDate ? formatKhmerDate(meta.reportDate) : 'ថ្ងៃទី....... ខែ....... ឆ្នាំ២០២...'}
            </div>
            <div className="font-bold text-black uppercase">
              ហត្ថលេខា និងឈ្មោះនាយកសាលា
            </div>
          </div>

          <div>
            <div className="w-48 mx-auto border-b border-dotted border-black mb-1"></div>
            <div className="font-bold text-slate-900 text-sm">
              {meta.principalName || '(ឈ្មោះនាយកសាលា)'}
            </div>
          </div>
        </div>

        {/* District Office Side */}
        <div className="text-center flex flex-col justify-between h-48">
          <div>
            <div className="text-slate-600 mb-1">
              {meta.verificationDate ? formatKhmerDate(meta.verificationDate) : 'ថ្ងៃទី....... ខែ....... ឆ្នាំ២០២...'}
            </div>
            <div className="font-bold text-black">
              បានពិនិត្យ និងបញ្ជាក់ថា ទិន្នន័យនេះពិតជាត្រឹមត្រូវអាចបញ្ចូលក្នុងប្រព័ន្ធបាន
            </div>
            <div className="font-semibold text-slate-700 mt-1">
              ហត្ថលេខា ការិយាល័យអប់រំ យុវជន និងកីឡា ស្រុក ខណ្ឌ
            </div>
          </div>

          <div>
            <div className="w-48 mx-auto border-b border-dotted border-black mb-1"></div>
            <div className="font-bold text-slate-900 text-sm">
              {meta.districtOfficerName || '(ឈ្មោះប្រធានការិយាល័យ/មន្ត្រីទទួលបន្ទុក)'}
            </div>
          </div>
        </div>

      </div>

      {/* Print Footer timestamp */}
      <div className="mt-8 pt-3 border-t border-slate-200 text-[10px] text-slate-500 flex justify-between items-center">
        <span>កាលបរិច្ឆេទផលិត៖ {new Date().toISOString().replace('T', ' ').substring(0, 19)}</span>
        <span>ទម្រង់ទី១១ ក្រសួងអប់រំ យុវជន និងកីឡា (MoEYS Form 11)</span>
      </div>

    </div>
  );
};
