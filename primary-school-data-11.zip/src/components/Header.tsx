import React from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Upload, 
  RotateCcw, 
  Sparkles, 
  BarChart3, 
  Edit3,
  Languages
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'edit' | 'preview' | 'analytics';
  setActiveTab: (tab: 'edit' | 'preview' | 'analytics') => void;
  onPrint: () => void;
  onLoadSample: () => void;
  onReset: () => void;
  onExportJSON: () => void;
  onImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  useKhmerDigits: boolean;
  setUseKhmerDigits: (val: boolean) => void;
  hasErrors: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onPrint,
  onLoadSample,
  onReset,
  onExportJSON,
  onImportJSON,
  useKhmerDigits,
  setUseKhmerDigits,
  hasErrors,
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-sm">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                  ទម្រង់ទី១១ • Form 11
                </span>
                <span className="text-xs text-slate-500">
                  ក្រសួងអប់រំ យុវជន និងកីឡា
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                ប្រព័ន្ធគ្រប់គ្រងទិន្នន័យសាលាបឋមសិក្សា
              </h1>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Tab switchers */}
            <div className="flex rounded-lg bg-slate-100 p-1 border border-slate-200">
              <button
                type="button"
                onClick={() => setActiveTab('edit')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'edit'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Edit3 className="w-4 h-4" />
                <span>បំពេញទិន្នន័យ</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'preview'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>ទម្រង់បោះពុម្ពផ្លូវការ</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('analytics')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-all relative ${
                  activeTab === 'analytics'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>វិភាគ & ផ្ទៀងផ្ទាត់</span>
                {hasErrors && (
                  <span className="w-2 h-2 rounded-full bg-amber-500 absolute -top-0.5 -right-0.5" />
                )}
              </button>
            </div>

            {/* Khmer Digits Toggle */}
            <button
              type="button"
              onClick={() => setUseKhmerDigits(!useKhmerDigits)}
              title="ប្តូររវាងលេខខ្មែរ និងលេខសកល (Toggle Khmer / Arabic digits)"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                useKhmerDigits
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{useKhmerDigits ? 'លេខខ្មែរ (០-៩)' : 'លេខសកល (0-9)'}</span>
            </button>

            {/* Sample Data */}
            <button
              type="button"
              onClick={onLoadSample}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 hover:text-blue-700 transition-colors shadow-xs"
              title="បញ្ចូលទិន្នន័យគំរូសាកល្បង"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span className="hidden sm:inline">ទិន្នន័យគំរូ</span>
            </button>

            {/* Export JSON */}
            <button
              type="button"
              onClick={onExportJSON}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
              title="ទាញយកជាឯកសារ JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">រក្សាទុក</span>
            </button>

            {/* Import JSON */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={onImportJSON}
              accept=".json"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
              title="បញ្ចូលឯកសារទិន្នន័យ"
            >
              <Upload className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">ផ្ទុកឡើង</span>
            </button>

            {/* Print button */}
            <button
              type="button"
              onClick={onPrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs sm:text-sm font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors shadow-xs"
            >
              <Printer className="w-4 h-4" />
              <span>បោះពុម្ព / Print</span>
            </button>

            {/* Reset */}
            <button
              type="button"
              onClick={onReset}
              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="សម្អាតទម្រង់ឡើងវិញ"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
