import React from 'react';
import { Form11Data } from '../types/form11';
import { FormAnalysis } from '../utils/validation';
import { toKhmerNumber } from '../utils/khmerNumerals';
import { 
  Users, 
  GraduationCap, 
  BookOpen, 
  Layers, 
  ShieldCheck, 
  TrendingUp,
  Percent,
  CalendarCheck
} from 'lucide-react';

interface AnalyticsSummaryProps {
  data: Form11Data;
  analysis: FormAnalysis;
  useKhmerDigits: boolean;
}

export const AnalyticsSummary: React.FC<AnalyticsSummaryProps> = ({
  data,
  analysis,
  useKhmerDigits,
}) => {
  const fmt = (n: number | string | null | undefined, decimals = 0) => {
    if (n === null || n === undefined || isNaN(Number(n))) return 'N/A';
    const val = typeof n === 'number' ? (decimals > 0 ? n.toFixed(decimals) : Math.round(n).toString()) : n.toString();
    return useKhmerDigits ? toKhmerNumber(val) : val;
  };

  const {
    totalStudents,
    femaleRatio,
    totalClasses,
    totalTeachers,
    pupilTeacherRatio,
    avgClassSizeG13,
    avgClassSizeG46,
    textbookCoverageG13,
    textbookCoverageG46,
    retentionEstimate,
  } = analysis;

  return (
    <div className="space-y-6">
      
      {/* Top Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Students */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">សិស្សសរុប</span>
            <div className="p-2 bg-blue-50 text-blue-700 rounded-lg">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {fmt(totalStudents)} <span className="text-xs font-normal text-slate-500">នាក់</span>
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>ប្រុស: {fmt(data.indicator14)}</span>
            <span>ស្រី: {fmt(data.indicator15)} ({fmt(femaleRatio, 1)}%)</span>
          </div>
        </div>

        {/* Total Classes */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">ថ្នាក់រៀនសរុប</span>
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {fmt(totalClasses)} <span className="text-xs font-normal text-slate-500">ថ្នាក់</span>
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>G1-3: {fmt(data.indicator3)}</span>
            <span>G4-6: {fmt(data.indicator4)}</span>
          </div>
        </div>

        {/* Pupil-Teacher Ratio */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">សមាមាត្រសិស្ស/គ្រូ</span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {fmt(pupilTeacherRatio, 1)} <span className="text-xs font-normal text-slate-500">: 1</span>
          </div>
          <div className="text-xs text-slate-500 mt-1">
            គ្រូបន្ទុកសរុប: {fmt(totalTeachers)} នាក់
          </div>
        </div>

        {/* Textbook Coverage Rate */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">អត្រាទទួលបានសៀវភៅ</span>
            <div className="p-2 bg-amber-50 text-amber-700 rounded-lg">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {fmt((textbookCoverageG13 + textbookCoverageG46) / 2, 1)}%
          </div>
          <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>G1-3: {fmt(textbookCoverageG13, 1)}%</span>
            <span>G4-6: {fmt(textbookCoverageG46, 1)}%</span>
          </div>
        </div>
      </div>

      {/* Analytical Breakdowns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Class Size Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-700" />
            <span>ទំហំថ្នាក់រៀន និងប្រសិទ្ធភាព</span>
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">មធ្យមភាគសិស្សក្នុងមួយថ្នាក់ (ថ្នាក់ទី១-៣):</span>
                <span className="font-bold text-slate-900">{fmt(avgClassSizeG13, 1)} នាក់/ថ្នាក់</span>
              </div>
              <div className="text-[11px] text-slate-500">
                ថ្នាក់ដែលមានសិស្ស ≤៤៥នាក់: <span className="font-semibold text-slate-700">{fmt(data.indicator7)}</span> / {fmt(data.indicator3)} ថ្នាក់
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">មធ្យមភាគសិស្សក្នុងមួយថ្នាក់ (ថ្នាក់ទី៤-៦):</span>
                <span className="font-bold text-slate-900">{fmt(avgClassSizeG46, 1)} នាក់/ថ្នាក់</span>
              </div>
              <div className="text-[11px] text-slate-500">
                ថ្នាក់ដែលមានសិស្ស ≤៤០នាក់: <span className="font-semibold text-slate-700">{fmt(data.indicator8)}</span> / {fmt(data.indicator4)} ថ្នាក់
              </div>
            </div>

            {retentionEstimate !== null && (
              <div className="pt-2 border-t border-slate-100">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600">អត្រារក្សាទុកគំរូ (ថ្នាក់ទី៦ ធៀប ថ្នាក់ទី១ កាលពី៦ឆ្នាំមុន):</span>
                  <span className="font-bold text-blue-700">{fmt(retentionEstimate, 1)}%</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  សិស្សថ្នាក់ទី៦ បច្ចុប្បន្ន ({fmt(data.indicator18)}) ធៀបនឹងសិស្សកាលពី ៦ឆ្នាំមុន ({fmt(data.indicator17)})
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Compliance & Health Directives */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>ការអនុវត្តគោលការណ៍ណែនាំសុខភាព និងប្រតិបត្តិការ</span>
          </h3>

          <div className="space-y-3">
            {/* Health contract */}
            <div className="p-3 rounded-lg border border-slate-200 flex items-start justify-between gap-3 bg-slate-50/50">
              <div className="text-xs">
                <div className="font-semibold text-slate-800">
                  #22 កិច្ចសន្យាអ្នកលក់ចំណីអាហារក្នុងសាលា
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  សេចក្តីណែនាំលេខ ១៨ អយក.សណ (លើកកម្ពស់សុខភាព និងសុខុមាលភាព)
                </div>
              </div>
              <span
                className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                  data.indicator22 === 'yes'
                    ? 'bg-emerald-100 text-emerald-800'
                    : data.indicator22 === 'no'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {data.indicator22 === 'yes' ? 'បានធ្វើ' : data.indicator22 === 'no' ? 'មិនទាន់ធ្វើ' : 'មិនទាន់បំពេញ'}
              </span>
            </div>

            {/* Health notice */}
            <div className="p-3 rounded-lg border border-slate-200 flex items-start justify-between gap-3 bg-slate-50/50">
              <div className="text-xs">
                <div className="font-semibold text-slate-800">
                  #23 បិទផ្សាយគោលការណ៍ណែនាំសុខភាពជាសាធារណៈ
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  ផ្សព្វផ្សាយនៅទីតាំងដែលសិស្ស និងអាណាព្យាបាលងាយមើលឃើញ
                </div>
              </div>
              <span
                className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                  data.indicator23 === 'yes'
                    ? 'bg-emerald-100 text-emerald-800'
                    : data.indicator23 === 'no'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {data.indicator23 === 'yes' ? 'បានបិទផ្សាយ' : data.indicator23 === 'no' ? 'មិនទាន់បិទ' : 'មិនទាន់បំពេញ'}
              </span>
            </div>

            {/* Operations */}
            <div className="p-3 rounded-lg border border-slate-200 flex items-start justify-between gap-3 bg-slate-50/50">
              <div className="text-xs">
                <div className="font-semibold text-slate-800">
                  #21 កិច្ចប្រជុំគណៈកម្មការគ្រប់គ្រងសាលា
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  ចំនួនលើកប្រជុំក្នុងមួយឆ្នាំ
                </div>
              </div>
              <span className="text-xs font-bold text-slate-900 bg-white px-2 py-1 rounded border border-slate-300">
                {fmt(data.indicator21)} លើក
              </span>
            </div>

            {/* 211 Teaching Days */}
            <div className="p-3 rounded-lg border border-slate-200 flex items-start justify-between gap-3 bg-slate-50/50">
              <div className="text-xs">
                <div className="font-semibold text-slate-800">
                  #13 សិស្សទទួលបានការបង្រៀន ២១១ ថ្ងៃពេញ
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  រាប់បញ្ចូលទាំងការបង្រៀនថ្ងៃព្រហស្បតិ៍
                </div>
              </div>
              <span className="text-xs font-bold text-slate-900 bg-white px-2 py-1 rounded border border-slate-300">
                {fmt(data.indicator13)} នាក់
              </span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
