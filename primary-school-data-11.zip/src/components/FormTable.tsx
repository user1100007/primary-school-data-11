import React, { useState } from 'react';
import { Form11Data, IndicatorDefinition, IndicatorKey } from '../types/form11';
import { INDICATORS } from '../data/initialData';
import { toKhmerNumber } from '../utils/khmerNumerals';
import { 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Search, 
  Filter,
  Check,
  X
} from 'lucide-react';

interface FormTableProps {
  data: Form11Data;
  onChange: (key: IndicatorKey, value: number | 'yes' | 'no' | '') => void;
  useKhmerDigits: boolean;
  relatedIssuesMap: Record<number, string[]>;
}

export const FormTable: React.FC<FormTableProps> = ({
  data,
  onChange,
  useKhmerDigits,
  relatedIssuesMap,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'ទាំងអស់ (២៣ សូចនាករ)' },
    { id: 'population', label: 'ផែនទីសិក្សា / កុមារ (#1, 2, 19)' },
    { id: 'classes', label: 'ថ្នាក់រៀន (#3, 4, 7, 8)' },
    { id: 'teachers', label: 'គ្រូបង្រៀន (#5, 6)' },
    { id: 'students', label: 'សិស្សានុសិស្ស (#9, 11, 14, 15...)' },
    { id: 'textbooks', label: 'សៀវភៅសិក្សាគោល (#10, 12)' },
    { id: 'operations', label: 'ប្រតិបត្តិការ & សុខភាព (#13, 21, 22, 23)' },
  ];

  const filteredIndicators = INDICATORS.filter((ind) => {
    const matchesCategory = selectedCategory === 'all' || ind.category === selectedCategory;
    const matchesSearch =
      ind.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ind.instruction && ind.instruction.toLowerCase().includes(searchTerm.toLowerCase())) ||
      ind.id.toString().includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden mb-6">
      
      {/* Table Header & Controls */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-900">
            បញ្ជីសូចនាករទាំង ២៣ នៃទម្រង់ទី១១
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            សូមបំពេញទិន្នន័យក្នុងប្រអប់នីមួយៗឲ្យបានត្រឹមត្រូវ តាមសេចក្តីណែនាំ
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ស្វែងរកសូចនាករ..."
              className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 w-40 sm:w-48"
            />
          </div>

          {/* Category selector */}
          <div className="flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-700"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100/75 text-slate-700 border-b border-slate-200 text-xs font-semibold uppercase tracking-wider">
              <th className="py-3 px-3 text-center w-12 sm:w-16">#</th>
              <th className="py-3 px-4 min-w-[280px]">សូចនាករ និងសេចក្តីណែនាំ</th>
              <th className="py-3 px-4 text-center w-40 sm:w-48">ទិន្នន័យបំពេញ</th>
              <th className="py-3 px-3 text-center w-28 sm:w-36">ស្ថានភាព</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredIndicators.map((ind: IndicatorDefinition) => {
              const val = data[ind.key];
              const issues = relatedIssuesMap[ind.id] || [];
              const hasError = issues.some((m) => m.includes('មិនត្រូវគ្នា') || m.includes('លើសពី') || m.includes('មិនអាច'));
              const isFilled = val !== '';

              return (
                <tr
                  key={ind.id}
                  className={`hover:bg-slate-50/80 transition-colors ${
                    hasError ? 'bg-red-50/40' : ''
                  }`}
                >
                  {/* Indicator ID */}
                  <td className="py-3 px-3 text-center font-bold text-slate-600 text-sm align-top pt-3.5">
                    <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-slate-100 text-slate-700 border border-slate-200">
                      {useKhmerDigits ? toKhmerNumber(ind.id) : ind.id}
                    </span>
                  </td>

                  {/* Indicator Name and Guidelines */}
                  <td className="py-3 px-4 align-top">
                    <div className="font-semibold text-slate-900 leading-snug">
                      {ind.name}
                      {ind.subLabel && (
                        <span className="ml-2 inline-block text-xs font-normal text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                          {ind.subLabel}
                        </span>
                      )}
                    </div>
                    {ind.instruction && (
                      <div className="flex items-start gap-1.5 mt-1 text-xs text-slate-500 bg-slate-50 p-2 rounded-md border border-slate-100">
                        <HelpCircle className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                        <span className="leading-relaxed">{ind.instruction}</span>
                      </div>
                    )}

                    {/* Specific dynamic notes */}
                    {ind.id === 9 && (
                      <div className="mt-1 text-xs text-blue-700 font-medium">
                        សិស្សថ្នាក់ទី១-៣: {data.indicator9 !== '' ? (useKhmerDigits ? toKhmerNumber(data.indicator9) : data.indicator9) : '0'} នាក់
                      </div>
                    )}
                    {ind.id === 11 && (
                      <div className="mt-1 text-xs text-blue-700 font-medium">
                        សិស្សថ្នាក់ទី៤-៦: {data.indicator11 !== '' ? (useKhmerDigits ? toKhmerNumber(data.indicator11) : data.indicator11) : '0'} នាក់
                      </div>
                    )}
                    {ind.id === 14 && data.indicator14 !== '' && data.indicator15 !== '' && (
                      <div className="mt-1 text-xs text-slate-600">
                        សរុបប្រុស+ស្រី: <span className="font-semibold text-slate-900">
                          {useKhmerDigits 
                            ? toKhmerNumber(Number(data.indicator14) + Number(data.indicator15)) 
                            : Number(data.indicator14) + Number(data.indicator15)}
                        </span> នាក់
                      </div>
                    )}
                  </td>

                  {/* Data Input Cell */}
                  <td className="py-3 px-4 align-top text-center">
                    {ind.type === 'number' ? (
                      <div className="flex flex-col items-center">
                        <input
                          type="number"
                          min="0"
                          value={typeof val === 'number' || val === '' ? val : ''}
                          onChange={(e) => {
                            const v = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value, 10));
                            onChange(ind.key, v);
                          }}
                          placeholder="០"
                          className={`w-full max-w-[150px] text-center font-bold text-base py-2 px-3 rounded-lg border focus:outline-none focus:ring-2 transition-all ${
                            hasError
                              ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-400'
                              : isFilled
                              ? 'border-blue-400 bg-blue-50/30 text-blue-900 focus:ring-blue-600'
                              : 'border-slate-300 bg-white text-slate-800 focus:ring-blue-600'
                          }`}
                        />
                        {useKhmerDigits && isFilled && (
                          <span className="text-xs text-slate-500 mt-1 font-medium">
                            = {toKhmerNumber(val as number)}
                          </span>
                        )}
                      </div>
                    ) : (
                      /* Boolean Type (Yes / No) */
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onChange(ind.key, 'yes')}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                            val === 'yes'
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>បាទ/ចាស</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onChange(ind.key, 'no')}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                            val === 'no'
                              ? 'bg-red-600 text-white border-red-600 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>ទេ</span>
                        </button>
                      </div>
                    )}
                  </td>

                  {/* Status / Validation message */}
                  <td className="py-3 px-3 align-top text-center">
                    {hasError ? (
                      <div
                        className="inline-flex items-center gap-1 text-xs text-red-700 bg-red-100 px-2.5 py-1 rounded-full font-medium"
                        title={issues.join('\n')}
                      >
                        <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                        <span>សូមផ្ទៀងផ្ទាត់</span>
                      </div>
                    ) : isFilled ? (
                      <div className="inline-flex items-center gap-1 text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>បានបំពេញ</span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-400 italic">
                        ទទេ
                      </span>
                    )}

                    {issues.length > 0 && !hasError && (
                      <div
                        className="mt-1 text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded text-left border border-amber-200"
                        title={issues.join('\n')}
                      >
                        <Info className="w-3 h-3 inline mr-1 text-amber-600" />
                        {issues[0].substring(0, 35)}...
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

    </div>
  );
};
