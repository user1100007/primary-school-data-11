import React from 'react';
import { SchoolMetadata } from '../types/form11';
import { Building2, Calendar, MapPin, UserCheck, Hash } from 'lucide-react';

interface SchoolMetaFormProps {
  metadata: SchoolMetadata;
  onChange: (field: keyof SchoolMetadata, value: string) => void;
}

export const SchoolMetaForm: React.FC<SchoolMetaFormProps> = ({ metadata, onChange }) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs mb-6">
      <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
        <Building2 className="w-5 h-5 text-blue-700" />
        <h2 className="text-base font-bold text-slate-800">
          ព័ត៌មានទូទៅរបស់សាលាបឋមសិក្សា
        </h2>
        <span className="text-xs text-slate-500 ml-auto">
          (បំពេញដោយនាយក ឬនាយិកាសាលា)
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
        
        {/* School Name */}
        <div className="lg:col-span-2">
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ឈ្មោះសាលាបឋមសិក្សា <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.schoolName}
              onChange={(e) => onChange('schoolName', e.target.value)}
              placeholder="ឧ. សាលាបឋមសិក្សា វត្តបូព៌"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
        </div>

        {/* Academic Year */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ឆ្នាំសិក្សា / របាយការណ៍ប្រចាំឆ្នាំ <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.academicYear}
              onChange={(e) => onChange('academicYear', e.target.value)}
              placeholder="ឧ. ២០២៤-២០២៥ ឬ ២០២៥"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            ចំពោះឆ្នាំសិក្សា ២០២៤-២០២៥ បំពេញ ២០២៥ បានហើយ
          </span>
        </div>

        {/* EMIS Code */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            លេខកូដសាលា (EMIS Code)
          </label>
          <div className="relative">
            <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.schoolCode || ''}
              onChange={(e) => onChange('schoolCode', e.target.value)}
              placeholder="ឧ. 17010401"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
        </div>

        {/* Province */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            រាជធានី / ខេត្ត
          </label>
          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.province}
              onChange={(e) => onChange('province', e.target.value)}
              placeholder="ឧ. សៀមរាប"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
        </div>

        {/* District */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ស្រុក / ខណ្ឌ / ក្រុង
          </label>
          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.district}
              onChange={(e) => onChange('district', e.target.value)}
              placeholder="ឧ. ក្រុងសៀមរាប"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
        </div>

        {/* Commune */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ឃុំ / សង្កាត់
          </label>
          <input
            type="text"
            value={metadata.commune}
            onChange={(e) => onChange('commune', e.target.value)}
            placeholder="ឧ. សាលាកំរើក"
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        {/* Village */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ភូមិ
          </label>
          <input
            type="text"
            value={metadata.village}
            onChange={(e) => onChange('village', e.target.value)}
            placeholder="ឧ. វត្តបូព៌"
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        {/* Principal Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ឈ្មោះនាយក ឬនាយិកាសាលា <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <UserCheck className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={metadata.principalName}
              onChange={(e) => onChange('principalName', e.target.value)}
              placeholder="ឈ្មោះនាយក ឬនាយិកា"
              className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
            />
          </div>
        </div>

        {/* Report Date */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            កាលបរិច្ឆេទធ្វើរបាយការណ៍
          </label>
          <input
            type="date"
            value={metadata.reportDate}
            onChange={(e) => onChange('reportDate', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        {/* District Officer Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            មន្ត្រីផ្ទៀងផ្ទាត់ (ការិយាល័យអប់រំ ស្រុក/ខណ្ឌ)
          </label>
          <input
            type="text"
            value={metadata.districtOfficerName || ''}
            onChange={(e) => onChange('districtOfficerName', e.target.value)}
            placeholder="ឈ្មោះមន្ត្រីការិយាល័យអប់រំ"
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

        {/* Verification Date */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            កាលបរិច្ឆេទផ្ទៀងផ្ទាត់
          </label>
          <input
            type="date"
            value={metadata.verificationDate || ''}
            onChange={(e) => onChange('verificationDate', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900 text-sm"
          />
        </div>

      </div>
    </div>
  );
};
