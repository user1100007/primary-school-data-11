import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Form11Data, SchoolMetadata, IndicatorKey } from './types/form11';
import { Form12Data, Form12Key } from './types/form12';
import { EMPTY_FORM_DATA, SAMPLE_FORM_DATA } from './data/initialData';
import { EMPTY_FORM12_DATA, SAMPLE_FORM12_DATA } from './data/form12Data';
import { analyzeForm11 } from './utils/validation';
import { OfficialFormSheet } from './components/OfficialFormSheet';
import { OfficialForm12Sheet } from './components/OfficialForm12Sheet';
import { ValidationAlerts } from './components/ValidationAlerts';
import { AnalyticsSummary } from './components/AnalyticsSummary';
import { YearSelectorBar } from './components/YearSelectorBar';
import { 
  auth, 
  loginWithGoogle, 
  logoutUser, 
  testConnection 
} from './firebase/config';
import { 
  saveForm11ToFirestore, 
  loadForm11FromFirestore, 
  saveForm12ToFirestore, 
  loadForm12FromFirestore, 
  fetchUserAvailableYears, 
  YearReportSummary 
} from './firebase/reportsService';
import { onAuthStateChanged, User } from 'firebase/auth';
import { 
  Printer, 
  Download, 
  Upload, 
  RotateCcw, 
  Sparkles, 
  Languages, 
  BarChart3, 
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCheck2,
  Coins,
  FileText
} from 'lucide-react';

const STORAGE_KEY_F11 = 'moeys_primary_school_form_11_data';
const STORAGE_KEY_F12 = 'moeys_primary_school_form_12_data';
const DIGITS_PREF_KEY = 'moeys_use_khmer_digits';

export const App: React.FC = () => {
  const [activeForm, setActiveForm] = useState<'form11' | 'form12'>('form11');
  const [user, setUser] = useState<User | null>(null);
  const [isSavingCloud, setIsSavingCloud] = useState<boolean>(false);
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);
  const [availableYears, setAvailableYears] = useState<YearReportSummary[]>([]);

  // Form 11 Data
  const [formData11, setFormData11] = useState<Form11Data>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_F11);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to read F11 from localStorage', e);
    }
    return SAMPLE_FORM_DATA;
  });

  // Form 12 Data
  const [formData12, setFormData12] = useState<Form12Data>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_F12);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to read F12 from localStorage', e);
    }
    return SAMPLE_FORM12_DATA;
  });

  const [useKhmerDigits, setUseKhmerDigits] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(DIGITS_PREF_KEY);
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [showAnalysisDrawer, setShowAnalysisDrawer] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Auth & Connection setup
  useEffect(() => {
    testConnection();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        refreshYearsList(currentUser.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  const refreshYearsList = useCallback(async (uid: string) => {
    const list = await fetchUserAvailableYears(uid);
    setAvailableYears(list);
  }, []);

  // Auto-save local backups
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_F11, JSON.stringify(formData11));
    } catch (e) {
      console.error('Failed to save F11 to localStorage', e);
    }
  }, [formData11]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_F12, JSON.stringify(formData12));
    } catch (e) {
      console.error('Failed to save F12 to localStorage', e);
    }
  }, [formData12]);

  useEffect(() => {
    try {
      localStorage.setItem(DIGITS_PREF_KEY, JSON.stringify(useKhmerDigits));
    } catch (e) {
      console.error('Failed to save digits pref', e);
    }
  }, [useKhmerDigits]);

  // Run validation for Form 11
  const analysis = useMemo(() => analyzeForm11(formData11), [formData11]);

  const relatedIssuesMap = useMemo(() => {
    const map: Record<number, string[]> = {};
    for (const issue of analysis.issues) {
      if (issue.relatedIndicators) {
        for (const indId of issue.relatedIndicators) {
          if (!map[indId]) map[indId] = [];
          map[indId].push(issue.message);
        }
      }
    }
    return map;
  }, [analysis.issues]);

  // Sync common metadata (School name, year, principal name, etc.)
  const handleMetadataChange = (field: keyof SchoolMetadata, value: string) => {
    setFormData11((prev) => ({
      ...prev,
      metadata: { ...prev.metadata, [field]: value },
    }));
    setFormData12((prev) => ({
      ...prev,
      metadata: { ...prev.metadata, [field]: value },
    }));
  };

  const handleIndicatorChange11 = (
    key: IndicatorKey,
    value: number | 'yes' | 'no' | ''
  ) => {
    setFormData11((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleIndicatorChange12 = (
    key: Form12Key,
    value: number | ''
  ) => {
    setFormData12((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  // Switch academic year
  const handleSelectYear = async (selectedYear: string) => {
    handleMetadataChange('academicYear', selectedYear);

    if (user) {
      // Try to load Form 11 and Form 12 from Firestore for this selected year
      try {
        const loadedF11 = await loadForm11FromFirestore(selectedYear, user.uid);
        if (loadedF11) {
          setFormData11(loadedF11);
        } else {
          setFormData11((prev) => ({
            ...EMPTY_FORM_DATA,
            metadata: {
              ...prev.metadata,
              academicYear: selectedYear,
            },
          }));
        }

        const loadedF12 = await loadForm12FromFirestore(selectedYear, user.uid);
        if (loadedF12) {
          setFormData12(loadedF12);
        } else {
          setFormData12((prev) => ({
            ...EMPTY_FORM12_DATA,
            metadata: {
              ...prev.metadata,
              academicYear: selectedYear,
            },
          }));
        }
        showToast(`បានបើកទិន្នន័យឆ្នាំ ${selectedYear}`);
      } catch (e) {
        console.error('Error switching year:', e);
      }
    }
  };

  // Add new academic year
  const handleAddNewYear = async (newYear: string) => {
    handleMetadataChange('academicYear', newYear);
    // Initialize fresh template for the new year with existing school name
    setFormData11((prev) => ({
      ...EMPTY_FORM_DATA,
      metadata: {
        ...prev.metadata,
        academicYear: newYear,
      },
    }));
    setFormData12((prev) => ({
      ...EMPTY_FORM12_DATA,
      metadata: {
        ...prev.metadata,
        academicYear: newYear,
      },
    }));
    showToast(`បានបង្កើតឆ្នាំសិក្សាថ្មី៖ ${newYear}`);
  };

  // Save to Cloud Firestore
  const handleSaveToCloud = async () => {
    if (!user) {
      if (window.confirm('សូមចូលគណនី Google ដើម្បីរក្សាទុកទិន្នន័យលើ Cloud Firestore។ តើអ្នកចង់ចូលគណនីឥឡូវនេះទេ?')) {
        try {
          await loginWithGoogle();
        } catch (e) {
          console.error('Login error', e);
        }
      }
      return;
    }

    try {
      setIsSavingCloud(true);
      await Promise.all([
        saveForm11ToFirestore(formData11, user.uid),
        saveForm12ToFirestore(formData12, user.uid),
      ]);
      await refreshYearsList(user.uid);
      const nowStr = new Date().toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit' });
      setLastSavedAt(nowStr);
      showToast('បានរក្សាទុកទិន្នន័យលើ Cloud Firestore ដោយជោគជ័យ!');
    } catch (err) {
      console.error('Error saving to cloud:', err);
      alert('មានបញ្ហាក្នុងការរក្សាទុកលើ Cloud។ សូមពិនិត្យមើលការភ្ជាប់អ៊ីនធឺណិត។');
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
      showToast('បានចូលគណនី Google');
    } catch (e) {
      console.error('Login error', e);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      showToast('បានចាកចេញពីគណនី');
    } catch (e) {
      console.error('Logout error', e);
    }
  };

  const handleLoadSample = () => {
    if (activeForm === 'form11') {
      if (window.confirm('តើអ្នកចង់បញ្ចូលទិន្នន័យគំរូសាកល្បង សម្រាប់ទម្រង់ទី១១ ដែរឬទេ?')) {
        setFormData11(SAMPLE_FORM_DATA);
        showToast('បានបញ្ចូលទិន្នន័យគំរូទម្រង់ទី១១ ជោគជ័យ!');
      }
    } else {
      if (window.confirm('តើអ្នកចង់បញ្ចូលទិន្នន័យគំរូសាកល្បង សម្រាប់ទម្រង់ទី១២ (ហិរញ្ញវត្ថុ) ដែរឬទេ?')) {
        setFormData12(SAMPLE_FORM12_DATA);
        showToast('បានបញ្ចូលទិន្នន័យគំរូទម្រង់ទី១២ ជោគជ័យ!');
      }
    }
  };

  const handleReset = () => {
    if (activeForm === 'form11') {
      if (window.confirm('តើអ្នកពិតជាចង់សម្អាតទម្រង់ទី១១ ទាំងអស់មែនទេ?')) {
        setFormData11(EMPTY_FORM_DATA);
        showToast('បានសម្អាតទម្រង់ទី១១ រួចរាល់');
      }
    } else {
      if (window.confirm('តើអ្នកពិតជាចង់សម្អាតទម្រង់ទី១២ (ហិរញ្ញវត្ថុ) ទាំងអស់មែនទេ?')) {
        setFormData12(EMPTY_FORM12_DATA);
        showToast('បានសម្អាតទម្រង់ទី១២ រួចរាល់');
      }
    }
  };

  const handleExportJSON = () => {
    const exportObject = {
      form11: formData11,
      form12: formData12,
      exportDate: new Date().toISOString(),
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportObject, null, 2));
    const downloadAnchor = document.createElement('a');
    const school = (formData11.metadata.schoolName || 'school').trim().replace(/\s+/g, '_');
    const year = (formData11.metadata.academicYear || 'year').trim().replace(/\s+/g, '_');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ទិន្នន័យសាលាបឋម_ទម្រង់១១_១២_${school}_${year}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('បានទាញយកឯកសារ JSON នៃទម្រង់ទាំងពីរ');
  };

  const handleExportCSV = () => {
    let rows: (string | number)[][] = [];

    if (activeForm === 'form11') {
      rows = [
        ['ទម្រង់ទី១១៖ ទិន្នន័យសាលាបឋមសិក្សា'],
        ['ឈ្មោះសាលា', formData11.metadata.schoolName],
        ['ឆ្នាំសិក្សា', formData11.metadata.academicYear],
        ['ល.រ', 'សូចនាករ', 'ទិន្នន័យបំពេញ'],
        ['1', 'ចំនួនកុមារអាយុពី៦ឆ្នាំ ឬយ៉ាងទាប៧០ខែ នៅក្នុងភូមិនៃផែនទីសិក្សា (សរុប)', formData11.indicator1],
        ['2', 'ចំនួនកុមារអាយុពី៦ឆ្នាំ ឬយ៉ាងទាប៧០ខែ នៅក្នុងភូមិនៃផែនទីសិក្សា (ស្រី)', formData11.indicator2],
        ['3', 'ចំនួនថ្នាក់រៀនពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣ សរុបទាំងអស់នៅក្នុងសាលារៀន', formData11.indicator3],
        ['4', 'ចំនួនថ្នាក់រៀនពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦ សរុបទាំងអស់នៅក្នុងសាលារៀន', formData11.indicator4],
        ['5', 'ចំនួនគ្រូទទួលបន្ទុកថ្នាក់ជាក់ស្ដែងពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣ សរុបនៅក្នុងសាលារៀន', formData11.indicator5],
        ['6', 'ចំនួនគ្រូទទួលបន្ទុកថ្នាក់ជាក់ស្ដែងពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦ សរុបនៅក្នុងសាលារៀន', formData11.indicator6],
        ['7', 'ចំនួនថ្នាក់រៀនដែលមានសិស្សតិចជាង ឬស្មើ៤៥នាក់ ក្នុងមួយថ្នាក់ ពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣', formData11.indicator7],
        ['8', 'ចំនួនថ្នាក់រៀនដែលមានសិស្សតិចជាង ឬស្មើ៤០នាក់ ក្នុងមួយថ្នាក់ ពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦', formData11.indicator8],
        ['9', 'ចំនួនសិស្សសរុបដែលរៀនថ្នាក់ទី១ ដល់ ថ្នាក់ទី៣', formData11.indicator9],
        ['10', 'ចំនួនសិស្សដែលរៀនថ្នាក់ទី១ ដល់ថ្នាក់ទី៣ ដែលបានទទួលសៀវភៅសិក្សាគោល ៣ ក្បាល', formData11.indicator10],
        ['11', 'ចំនួនសិស្សសរុបដែលរៀនថ្នាក់ទី៤ ដល់ថ្នាក់ទី ៦', formData11.indicator11],
        ['12', 'ចំនួនសិស្សដែលរៀនថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦ ដែលបានទទួលសៀវភៅសិក្សាគោល ៤ក្បាល', formData11.indicator12],
        ['13', 'ចំនួនថ្នាក់រៀនដែលបានទទួលការបង្រៀន រយៈពេល២១១ ថ្ងៃពេញ', formData11.indicator13],
        ['14', 'ចំនួនសិស្សប្រុសសរុប នៅក្នុងសាលា', formData11.indicator14],
        ['15', 'ចំនួនសិស្សស្រីសរុប នៅក្នុងសាលា', formData11.indicator15],
        ['16', 'ចំនួនសិស្សសរុបដែលរៀនត្រួតថ្នាក់', formData11.indicator16],
        ['17', 'ចំនួនសិស្សដែលរៀនថ្នាក់ទី១ កាលពី ៦ឆ្នាំមុន', formData11.indicator17],
        ['18', 'ចំនួនសិស្សដែលរៀនថ្នាក់ទី៦', formData11.indicator18],
        ['19', 'ចំនួនកុមារដែលមានអាយុ១១ឆ្នាំ', formData11.indicator19],
        ['20', 'ចំនួនសិស្សថ្មីដែលចូលរៀនថ្នាក់ទី១', formData11.indicator20],
        ['21', 'ចំនួនកិច្ចប្រជុំរបស់គណៈកម្មការគ្រប់គ្រងសាលាដែលបានរៀបចំក្នុងមួយឆ្នាំ', formData11.indicator21],
        ['22', 'កិច្ចសន្យាជាមួយអ្នកលក់ចំណីអាហារលើកកម្ពស់សុខភាព', formData11.indicator22],
        ['23', 'បិទផ្សាយគោលការណ៍ណែនាំស្តីពីសុខភាព', formData11.indicator23],
      ];
    } else {
      rows = [
        ['ទម្រង់ទី១២៖ ហិរញ្ញវត្ថុសាលាបឋមសិក្សា'],
        ['ឈ្មោះសាលា', formData12.metadata.schoolName],
        ['ឆ្នាំសិក្សា', formData12.metadata.academicYear],
        ['ផ្នែក', 'ល.រ', 'បរិយាយ', 'ជាក់ស្ដែង (រៀល)'],
        ['ចំណូល', '1', 'ថវិការដ្ឋ', formData12.income1],
        ['ចំណូល', '2', 'ថវិកាដៃគូ', formData12.income2],
        ['ចំណូល', '3', 'ថវិកាសហគមន៍', formData12.income3],
        ['ចំណូល', '4', 'ថវិកាផ្សេងៗ', formData12.income4],
        ['ចំណាយ', '5', 'ប្រាក់បៀវត្ស និងប្រាក់ឧបត្ថម្ភសម្រាប់ គ្រូបង្រៀន', formData12.expense5],
        ['ចំណាយ', '6', 'គាំទ្រកិច្ចដំណើរការសាលារៀន', formData12.expense6],
        ['ចំណាយ', '7', 'កែលម្អគុណភាពនៃការអប់រំ', formData12.expense7],
      ];
    }

    const csvContent =
      '\uFEFF' +
      rows
        .map((r) => r.map((c) => `"${(c ?? '').toString().replace(/"/g, '""')}"`).join(','))
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', url);
    downloadAnchor.setAttribute('download', `${activeForm === 'form11' ? 'ទម្រង់១១' : 'ទម្រង់១២'}_${formData11.metadata.schoolName || 'school'}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('បានទាញយកឯកសារ CSV');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], 'UTF-8');
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed.form11 || parsed.indicator1 !== undefined) {
            if (parsed.form11) setFormData11(parsed.form11);
            else setFormData11(parsed);
          }
          if (parsed.form12 || parsed.income1 !== undefined) {
            if (parsed.form12) setFormData12(parsed.form12);
            else setFormData12(parsed);
          }
          showToast('បានផ្ទុកឡើងទិន្នន័យជោគជ័យ!');
        } catch {
          alert('ឯកសារ JSON មិនត្រឹមត្រូវ សូមពិនិត្យឡើងវិញ');
        }
      };
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-200/70 text-slate-900 pb-12">
      
      {/* Top Application Toolbar (Hidden on Print) */}
      <header className="bg-slate-900 text-white sticky top-0 z-30 shadow-md no-print border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3">
          
          {/* Logo & Form Switcher */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
              {activeForm === 'form11' ? '១១' : '១២'}
            </div>
            
            {/* Form Selection Tabs */}
            <div className="flex rounded-lg bg-slate-800 p-1 border border-slate-700">
              <button
                type="button"
                onClick={() => setActiveForm('form11')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs sm:text-sm font-semibold transition-all ${
                  activeForm === 'form11'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>ទម្រង់ទី១១ (ទិន្នន័យសាលា)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveForm('form12')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs sm:text-sm font-semibold transition-all ${
                  activeForm === 'form12'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Coins className="w-4 h-4" />
                <span>ទម្រង់ទី១២ (ហិរញ្ញវត្ថុ)</span>
              </button>
            </div>
          </div>

          {/* Balance Status Badge for Form 11 */}
          {activeForm === 'form11' && (
            <button
              type="button"
              onClick={() => setShowAnalysisDrawer(!showAnalysisDrawer)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all border ${
                analysis.isTotalBalanced
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50 hover:bg-emerald-900'
                  : 'bg-red-950/80 text-red-300 border-red-500/50 hover:bg-red-900 animate-pulse'
              }`}
            >
              {analysis.isTotalBalanced ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              )}
              <span>
                {analysis.isTotalBalanced
                  ? 'តុល្យភាពសិស្ស៖ ត្រឹមត្រូវ'
                  : 'តុល្យភាពសិស្ស៖ មិនទាន់ត្រូវគ្នា'}
              </span>
            </button>
          )}

          {/* Action Tools */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Number Script Toggle */}
            <button
              type="button"
              onClick={() => setUseKhmerDigits(!useKhmerDigits)}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border transition-colors ${
                useKhmerDigits
                  ? 'bg-blue-600 text-white border-blue-500'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
              title="ប្តូររវាងលេខខ្មែរ (០-៩) និងលេខសកល (0-9)"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{useKhmerDigits ? 'លេខខ្មែរ (០-៩)' : 'លេខសកល (0-9)'}</span>
            </button>

            {/* Analysis Stats toggle */}
            {activeForm === 'form11' && (
              <button
                type="button"
                onClick={() => setShowAnalysisDrawer(!showAnalysisDrawer)}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-800 text-slate-300 hover:text-white border border-slate-700 rounded transition-colors"
              >
                <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                <span>ស្ថិតិ</span>
              </button>
            )}

            {/* Sample Data */}
            <button
              type="button"
              onClick={handleLoadSample}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-800 text-slate-300 hover:text-white border border-slate-700 rounded transition-colors"
              title="បញ្ចូលទិន្នន័យគំរូ"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">ទិន្នន័យគំរូ</span>
            </button>

            {/* Export JSON */}
            <button
              type="button"
              onClick={handleExportJSON}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
              title="ទាញយក JSON"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Import JSON */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImportJSON}
              accept=".json"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
              title="ផ្ទុកឡើង JSON"
            >
              <Upload className="w-4 h-4" />
            </button>

            {/* CSV */}
            <button
              type="button"
              onClick={handleExportCSV}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
              title="ទាញយក CSV / Excel"
            >
              <FileSpreadsheet className="w-4 h-4" />
            </button>

            {/* Reset */}
            <button
              type="button"
              onClick={handleReset}
              className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition-colors"
              title="សម្អាតទម្រង់"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Print button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors shadow-xs ml-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>បោះពុម្ព (Print)</span>
            </button>
          </div>

        </div>
      </header>

      {/* Year Selector & Cloud Sync Bar */}
      <YearSelectorBar
        currentYear={formData11.metadata.academicYear}
        onSelectYear={handleSelectYear}
        availableYears={availableYears}
        onAddNewYear={handleAddNewYear}
        onSaveToCloud={handleSaveToCloud}
        isSaving={isSavingCloud}
        user={user}
        onLogin={handleLogin}
        onLogout={handleLogout}
        lastSavedAt={lastSavedAt}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-2 rounded-lg shadow-xl flex items-center gap-2 text-xs font-medium animate-fade-in no-print">
          <FileCheck2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Analysis & Validation Modal / Drawer for Form 11 */}
      {showAnalysisDrawer && (
        <div className="no-print fixed inset-0 z-40 bg-black/50 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-full max-w-xl h-full shadow-2xl p-6 overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3 mb-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-700" />
                <h2 className="text-base font-bold text-slate-900">
                  ការផ្ទៀងផ្ទាត់ និងស្ថិតិអប់រំ (ទម្រង់ទី១១)
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowAnalysisDrawer(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <ValidationAlerts
              analysis={analysis}
              useKhmerDigits={useKhmerDigits}
            />

            <AnalyticsSummary
              data={formData11}
              analysis={analysis}
              useKhmerDigits={useKhmerDigits}
            />
          </div>
        </div>
      )}

      {/* Main Document Canvas */}
      <main className="max-w-4xl mx-auto px-2 sm:px-4 pt-6 print:p-0 print:m-0 print:max-w-none">
        
        {/* Render Form 11 */}
        {activeForm === 'form11' && (
          <OfficialFormSheet
            data={formData11}
            onChange={handleIndicatorChange11}
            onMetaChange={handleMetadataChange}
            useKhmerDigits={useKhmerDigits}
            relatedIssuesMap={relatedIssuesMap}
          />
        )}

        {/* Render Form 12 */}
        {activeForm === 'form12' && (
          <OfficialForm12Sheet
            data={formData12}
            onChange={handleIndicatorChange12}
            onMetaChange={handleMetadataChange}
            useKhmerDigits={useKhmerDigits}
          />
        )}

      </main>

    </div>
  );
};

export default App;
