import { 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  getDocs, 
  query, 
  where 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './config';
import { Form11Data } from '../types/form11';
import { Form12Data } from '../types/form12';

function buildDocId(academicYear: string, userId: string, formType: string): string {
  // Normalize year to safe alphanumeric key
  const safeYear = academicYear
    .replace(/\s+/g, '_')
    .replace(/[^a-zA-Z0-9_\u17E0-\u17E9-]/g, '')
    .substring(0, 30) || 'default_year';
  const safeUser = userId.substring(0, 30);
  return `${formType}_${safeYear}_${safeUser}`.replace(/[^a-zA-Z0-9_\\-]/g, '_');
}

export async function saveForm11ToFirestore(
  data: Form11Data,
  userId: string
): Promise<void> {
  const docId = buildDocId(data.metadata.academicYear, userId, 'f11');
  const path = `form11_reports/${docId}`;
  try {
    const payload = {
      ...data,
      id: docId,
      schoolName: data.metadata.schoolName || 'សាលាបឋមសិក្សា',
      academicYear: data.metadata.academicYear || '២០២៥',
      authorId: userId,
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'form11_reports', docId), payload, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function loadForm11FromFirestore(
  academicYear: string,
  userId: string
): Promise<Form11Data | null> {
  const docId = buildDocId(academicYear, userId, 'f11');
  const path = `form11_reports/${docId}`;
  try {
    const snapshot = await getDoc(doc(db, 'form11_reports', docId));
    if (snapshot.exists()) {
      return snapshot.data() as Form11Data;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveForm12ToFirestore(
  data: Form12Data,
  userId: string
): Promise<void> {
  const docId = buildDocId(data.metadata.academicYear, userId, 'f12');
  const path = `form12_reports/${docId}`;
  try {
    const n = (v: number | '') => (typeof v === 'number' ? v : 0);
    const totalIncome = n(data.income1) + n(data.income2) + n(data.income3) + n(data.income4);
    const totalExpense = n(data.expense5) + n(data.expense6) + n(data.expense7);
    const netBalance = totalIncome - totalExpense;

    const payload = {
      ...data,
      id: docId,
      schoolName: data.metadata.schoolName || 'សាលាបឋមសិក្សា',
      academicYear: data.metadata.academicYear || '២០២៦',
      totalIncome,
      totalExpense,
      netBalance,
      authorId: userId,
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'form12_reports', docId), payload, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function loadForm12FromFirestore(
  academicYear: string,
  userId: string
): Promise<Form12Data | null> {
  const docId = buildDocId(academicYear, userId, 'f12');
  const path = `form12_reports/${docId}`;
  try {
    const snapshot = await getDoc(doc(db, 'form12_reports', docId));
    if (snapshot.exists()) {
      return snapshot.data() as Form12Data;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export interface YearReportSummary {
  academicYear: string;
  schoolName: string;
  hasForm11: boolean;
  hasForm12: boolean;
  updatedAt?: string;
}

export async function fetchUserAvailableYears(userId: string): Promise<YearReportSummary[]> {
  const yearsMap: Record<string, YearReportSummary> = {};

  try {
    // List user's Form 11 reports
    const q11 = query(
      collection(db, 'form11_reports'),
      where('authorId', '==', userId)
    );
    const snap11 = await getDocs(q11);
    snap11.forEach((d) => {
      const data = d.data();
      const yr = data.academicYear || 'Unknown';
      if (!yearsMap[yr]) {
        yearsMap[yr] = {
          academicYear: yr,
          schoolName: data.schoolName || '',
          hasForm11: true,
          hasForm12: false,
          updatedAt: data.updatedAt,
        };
      } else {
        yearsMap[yr].hasForm11 = true;
      }
    });

    // List user's Form 12 reports
    const q12 = query(
      collection(db, 'form12_reports'),
      where('authorId', '==', userId)
    );
    const snap12 = await getDocs(q12);
    snap12.forEach((d) => {
      const data = d.data();
      const yr = data.academicYear || 'Unknown';
      if (!yearsMap[yr]) {
        yearsMap[yr] = {
          academicYear: yr,
          schoolName: data.schoolName || '',
          hasForm11: false,
          hasForm12: true,
          updatedAt: data.updatedAt,
        };
      } else {
        yearsMap[yr].hasForm12 = true;
      }
    });

    return Object.values(yearsMap).sort((a, b) => b.academicYear.localeCompare(a.academicYear));
  } catch (err) {
    console.warn('[Firestore] Error fetching years list:', err);
    return [];
  }
}
