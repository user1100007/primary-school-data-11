import { Form11Data, ValidationIssue } from '../types/form11';

export interface FormAnalysis {
  totalByGrades: number;
  totalByGender: number;
  isTotalBalanced: boolean;
  totalStudents: number;
  femaleRatio: number;
  totalClasses: number;
  totalTeachers: number;
  pupilTeacherRatio: number;
  avgClassSizeG13: number;
  avgClassSizeG46: number;
  textbookCoverageG13: number;
  textbookCoverageG46: number;
  retentionEstimate: number | null;
  issues: ValidationIssue[];
}

export function analyzeForm11(data: Form11Data): FormAnalysis {
  const issues: ValidationIssue[] = [];

  const n = (val: number | string): number => {
    const num = Number(val);
    return isNaN(num) ? 0 : num;
  };

  const ind1 = n(data.indicator1);
  const ind2 = n(data.indicator2);
  const ind3 = n(data.indicator3);
  const ind4 = n(data.indicator4);
  const ind5 = n(data.indicator5);
  const ind6 = n(data.indicator6);
  const ind7 = n(data.indicator7);
  const ind8 = n(data.indicator8);
  const ind9 = n(data.indicator9);
  const ind10 = n(data.indicator10);
  const ind11 = n(data.indicator11);
  const ind12 = n(data.indicator12);
  const ind13 = n(data.indicator13);
  const ind14 = n(data.indicator14);
  const ind15 = n(data.indicator15);
  const ind16 = n(data.indicator16);
  const ind17 = n(data.indicator17);
  const ind18 = n(data.indicator18);
  const ind19 = n(data.indicator19);
  const ind20 = n(data.indicator20);

  const totalByGrades = ind9 + ind11;
  const totalByGender = ind14 + ind15;

  const hasEnteredGrades = data.indicator9 !== '' || data.indicator11 !== '';
  const hasEnteredGender = data.indicator14 !== '' || data.indicator15 !== '';

  const isTotalBalanced = !hasEnteredGrades || !hasEnteredGender || totalByGrades === totalByGender;

  if (hasEnteredGrades && hasEnteredGender && totalByGrades !== totalByGender) {
    issues.push({
      type: 'error',
      message: `ចំនួនសិស្សសរុបមិនត្រូវគ្នាទេ៖ សរុបតាមកម្រិតថ្នាក់ (ថ្នាក់ទី១-៣ + ថ្នាក់ទី៤-៦) = ${totalByGrades} នាក់ តែសរុបតាមភេទ (ប្រុស + ស្រី) = ${totalByGender} នាក់។ សូមផ្ទៀងផ្ទាត់ឡើងវិញ!`,
      relatedIndicators: [9, 11, 14, 15],
    });
  }

  // Population check: ind2 <= ind1
  if (data.indicator1 !== '' && data.indicator2 !== '' && ind2 > ind1) {
    issues.push({
      type: 'error',
      message: `កុមារីអាយុ ៦ឆ្នាំ (${ind2}) មិនអាចច្រើនជាងចំនួនកុមារសរុប (${ind1}) ឡើយ។`,
      relatedIndicators: [1, 2],
    });
  }

  // Textbooks check
  if (data.indicator9 !== '' && data.indicator10 !== '' && ind10 > ind9) {
    issues.push({
      type: 'error',
      message: `ចំនួនសិស្សថ្នាក់ទី១-៣ ដែលបានសៀវភៅ ៣ក្បាល (${ind10}) លើសពីចំនួនសិស្សថ្នាក់ទី១-៣ សរុប (${ind9})។`,
      relatedIndicators: [9, 10],
    });
  }

  if (data.indicator11 !== '' && data.indicator12 !== '' && ind12 > ind11) {
    issues.push({
      type: 'error',
      message: `ចំនួនសិស្សថ្នាក់ទី៤-៦ ដែលបានសៀវភៅ ៤ក្បាល (${ind12}) លើសពីចំនួនសិស្សថ្នាក់ទី៤-៦ សរុប (${ind11})។`,
      relatedIndicators: [11, 12],
    });
  }

  // Class size check
  if (data.indicator3 !== '' && data.indicator7 !== '' && ind7 > ind3) {
    issues.push({
      type: 'error',
      message: `ចំនួនថ្នាក់ទី១-៣ ដែលមានសិស្ស ≤៤៥នាក់ (${ind7}) មិនអាចលើសពីចំនួនថ្នាក់សរុប (${ind3}) ឡើយ។`,
      relatedIndicators: [3, 7],
    });
  }

  if (data.indicator4 !== '' && data.indicator8 !== '' && ind8 > ind4) {
    issues.push({
      type: 'error',
      message: `ចំនួនថ្នាក់ទី៤-៦ ដែលមានសិស្ស ≤៤០នាក់ (${ind8}) មិនអាចលើសពីចំនួនថ្នាក់សរុប (${ind4}) ឡើយ។`,
      relatedIndicators: [4, 8],
    });
  }

  // Grade 6 check
  if (data.indicator11 !== '' && data.indicator18 !== '' && ind18 > ind11) {
    issues.push({
      type: 'warning',
      message: `ចំនួនសិស្សថ្នាក់ទី៦ (${ind18}) ច្រើនជាងចំនួនសិស្សថ្នាក់ទី៤ ដល់ទី៦ សរុប (${ind11})។ សូមពិនិត្យឡើងវិញ។`,
      relatedIndicators: [11, 18],
    });
  }

  // Repeater check
  const totalStudents = totalByGrades > 0 ? totalByGrades : totalByGender;
  if (totalStudents > 0 && data.indicator16 !== '' && ind16 > totalStudents) {
    issues.push({
      type: 'error',
      message: `ចំនួនសិស្សរៀនត្រួតថ្នាក់ (${ind16}) លើសពីចំនួនសិស្សសរុប (${totalStudents})។`,
      relatedIndicators: [16],
    });
  }

  // Teacher check: 1 teacher per class rule
  if (data.indicator3 !== '' && data.indicator5 !== '' && ind5 !== ind3) {
    issues.push({
      type: 'info',
      message: `ថ្នាក់ទី១-៣ មាន ${ind3} ថ្នាក់ និងគ្រូទទួលបន្ទុក ${ind5} នាក់ (សេចក្តីណែនាំកំណត់ថា គ្រូម្នាក់ទទួលបន្ទុកបានតែ១ថ្នាក់)។`,
      relatedIndicators: [3, 5],
    });
  }
  if (data.indicator4 !== '' && data.indicator6 !== '' && ind6 !== ind4) {
    issues.push({
      type: 'info',
      message: `ថ្នាក់ទី៤-៦ មាន ${ind4} ថ្នាក់ និងគ្រូទទួលបន្ទុក ${ind6} នាក់ (សេចក្តីណែនាំកំណត់ថា គ្រូម្នាក់ទទួលបន្ទុកបានតែ១ថ្នាក់)។`,
      relatedIndicators: [4, 6],
    });
  }

  // MoEYS health directive checks
  if (data.indicator22 === 'no') {
    issues.push({
      type: 'warning',
      message: 'សាលាមិនទាន់បានធ្វើកិច្ចសន្យាជាមួយអ្នកលក់ចំណីអាហារ តាមសេចក្តីណែនាំលេខ ១៨ អយក.សណ នៅឡើយ។',
      relatedIndicators: [22],
    });
  }
  if (data.indicator23 === 'no') {
    issues.push({
      type: 'warning',
      message: 'សាលាមិនទាន់បានបិទផ្សាយគោលការណ៍ណែនាំស្តីពីការលើកកម្ពស់សុខភាព និងសុខុមាលភាពចំណីអាហារជាសាធារណៈ។',
      relatedIndicators: [23],
    });
  }

  const femaleRatio = totalStudents > 0 ? (ind15 / totalStudents) * 100 : 0;
  const totalClasses = ind3 + ind4;
  const totalTeachers = ind5 + ind6;
  const pupilTeacherRatio = totalTeachers > 0 ? totalStudents / totalTeachers : 0;
  const avgClassSizeG13 = ind3 > 0 ? ind9 / ind3 : 0;
  const avgClassSizeG46 = ind4 > 0 ? ind11 / ind4 : 0;
  const textbookCoverageG13 = ind9 > 0 ? (ind10 / ind9) * 100 : 0;
  const textbookCoverageG46 = ind11 > 0 ? (ind12 / ind11) * 100 : 0;
  const retentionEstimate = ind17 > 0 && ind18 > 0 ? (ind18 / ind17) * 100 : null;

  return {
    totalByGrades,
    totalByGender,
    isTotalBalanced,
    totalStudents,
    femaleRatio,
    totalClasses,
    totalTeachers,
    pupilTeacherRatio,
    avgClassSizeG13,
    avgClassSizeG46,
    textbookCoverageG13,
    textbookCoverageG46,
    retentionEstimate,
    issues,
  };
}
