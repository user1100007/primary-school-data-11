const khmerDigits = ['០', '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩'];

export function toKhmerNumber(num: number | string | undefined | null): string {
  if (num === undefined || num === null || num === '') return '';
  return num
    .toString()
    .replace(/[0-9]/g, (digit) => khmerDigits[parseInt(digit, 10)]);
}

export function fromKhmerNumber(str: string): string {
  return str.replace(/[០-៩]/g, (digit) => {
    const idx = khmerDigits.indexOf(digit);
    return idx >= 0 ? idx.toString() : digit;
  });
}

export function formatKhmerDate(dateString?: string): string {
  if (!dateString) return 'ថ្ងៃទី....... ខែ....... ឆ្នាំ២០២...';
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    const day = date.getDate();
    const months = [
      'មករា', 'កុម្ភៈ', 'មីនា', 'មេសា', 'ឧសភា', 'មិថុនា',
      'កក្កដា', 'សីហា', 'កញ្ញា', 'តុលា', 'វិច្ឆិកា', 'ធ្នូ'
    ];
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    return `ថ្ងៃទី ${toKhmerNumber(day)} ខែ ${month} ឆ្នាំ ${toKhmerNumber(year)}`;
  } catch {
    return dateString;
  }
}
