import { Form12Data, Form12ItemDefinition } from '../types/form12';

export const FORM12_INCOME_ITEMS: Form12ItemDefinition[] = [
  {
    id: 1,
    key: 'income1',
    section: 'income',
    name: 'ថវិការដ្ឋ',
    description:
      'ថវិកាដែលបានផ្ទេរពីរដ្ឋាភិបាល ដោយក្រសួងសេដ្ឋកិច្ចនិងហិរញ្ញវត្ថុ។ រាប់បញ្ចូលប្រាក់បៀវត្ស និងប្រាក់ឧបត្ថម្ភនាយកសាលា គ្រូបង្រៀន និងបុគ្គលិក',
  },
  {
    id: 2,
    key: 'income2',
    section: 'income',
    name: 'ថវិកាដៃគូ',
    description:
      'ដៃគូអភិវឌ្ឍន៍ទាំងអស់ដែលចូលរួមជួយសាលារៀនសាធារណៈ តាមរយៈមូលនិធិដំណើរការសាលារៀនសាធារណៈ',
  },
  {
    id: 3,
    key: 'income3',
    section: 'income',
    name: 'ថវិកាសហគមន៍',
    description:
      'សហគមន៍ និងសប្បុរសជនក្នុងការចូលរួមផ្តល់ថវិកាតាមរយៈការ តែងឆ្ងល់ បុណ្យផ្កាសាមគ្គី ការប្រមូលកិច្ចក្ដា ការប្រាក់តម្កល់ និង ការស្វែងរកផលប្រយោជន៍ផ្សេងៗ ដើម្បីរួមចំណែកក្នុងមូលនិធិ ដំណើរការសាលារៀនសាធារណៈ។',
  },
  {
    id: 4,
    key: 'income4',
    section: 'income',
    name: 'ថវិកាផ្សេងៗ',
    description:
      'គ្រប់ចំណូលដែលបានពីប្រភពផ្សេងៗ ដូចជាការលក់ផលិតផល ផ្សេងៗ ផលិតផលកសិផល ភាស៊ីផ្លូវ ម៉ូតូ អាហារដ្ឋាន តូប លក់ ចំណូលការប្រាក់ពីធនាគារ និងការជួលផ្សេងៗនៅក្នុង សាលារៀន ត្រូវបង់ចូលជាមូលនិធិដំណើរការសាលារៀន សាធារណៈ។',
  },
];

export const FORM12_EXPENSE_ITEMS: Form12ItemDefinition[] = [
  {
    id: 5,
    key: 'expense5',
    section: 'expense',
    name: 'ប្រាក់បៀវត្ស និងប្រាក់ឧបត្ថម្ភសម្រាប់ គ្រូបង្រៀន',
    description:
      'ប្រាក់បៀវត្សនាយកសាលា គ្រូបង្រៀន និងបុគ្គលិកផ្សេងៗ កិច្ចប្រជុំ ថ្ងៃព្រហស្បតិ៍ ការងារបន្ថែមម៉ោង ការបង្រៀនថ្នាក់ ពិសេស និង ថ្នាក់គួប ប្រាក់តំបន់',
  },
  {
    id: 6,
    key: 'expense6',
    section: 'expense',
    name: 'គាំទ្រកិច្ចដំណើរការសាលារៀន',
    description:
      'ការងាររដ្ឋបាល ការបង្រៀន សម្ភារៈបរិក្ខារ និងសង្គម ការសាងសង់ ការថែទាំជួសជុល និងសេវាផ្សេងៗ (ទឹក ភ្លើង...)',
  },
  {
    id: 7,
    key: 'expense7',
    section: 'expense',
    name: 'កែលម្អគុណភាពនៃការអប់រំ',
    description:
      'ការចូលរៀនដោយសមធម៌ សម្ភារៈរៀន និងបង្រៀន ការកែលម្អ បរិស្ថាន និងទីធ្លាអគារ អប់រំបំណិនជីវិត កីឡា ការងារយុវជន និង កុមារ ប្រាក់អាហារូបករណ៍ (ថវិការដ្ឋ) បង្រៀនសិស្សបោះបង់ និង ការងារយុវជន និងកុមារ (ការចូលរួមក្នុងសកម្មភាពសង្គមសម្រាប់ ចំណាយអាហារូបករណ៍ និងការវិនិយោគ) (ក្រៅពីថវិការដ្ឋ)',
  },
];

export const EMPTY_FORM12_DATA: Form12Data = {
  metadata: {
    schoolName: '',
    academicYear: '២០២៦',
    province: '',
    district: '',
    commune: '',
    village: '',
    principalName: '',
    schoolCode: '',
    reportDate: '',
    districtOfficerName: '',
    verificationDate: '',
  },
  income1: '',
  income2: '',
  income3: '',
  income4: '',
  expense5: '',
  expense6: '',
  expense7: '',
};

export const SAMPLE_FORM12_DATA: Form12Data = {
  metadata: {
    schoolName: 'រោគ',
    academicYear: '២០២៦',
    province: 'សៀមរាប',
    district: 'ក្រុងសៀមរាប',
    commune: '',
    village: '',
    principalName: '',
    schoolCode: '',
    reportDate: '',
    districtOfficerName: '',
    verificationDate: '',
  },
  income1: 85000000,
  income2: 12000000,
  income3: 6500000,
  income4: 3200000,
  expense5: 75000000,
  expense6: 18500000,
  expense7: 11000000,
};
