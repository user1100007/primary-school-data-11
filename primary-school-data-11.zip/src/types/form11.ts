export interface SchoolMetadata {
  schoolName: string;
  academicYear: string;
  province: string;
  district: string;
  commune: string;
  village: string;
  principalName: string;
  schoolCode?: string;
  reportDate: string;
  districtOfficerName?: string;
  verificationDate?: string;
}

export type IndicatorKey =
  | 'indicator1'
  | 'indicator2'
  | 'indicator3'
  | 'indicator4'
  | 'indicator5'
  | 'indicator6'
  | 'indicator7'
  | 'indicator8'
  | 'indicator9'
  | 'indicator10'
  | 'indicator11'
  | 'indicator12'
  | 'indicator13'
  | 'indicator14'
  | 'indicator15'
  | 'indicator16'
  | 'indicator17'
  | 'indicator18'
  | 'indicator19'
  | 'indicator20'
  | 'indicator21'
  | 'indicator22'
  | 'indicator23';

export interface Form11Data {
  metadata: SchoolMetadata;
  // Indicators 1 to 23
  indicator1: number | ''; // ចំនួនកុមារអាយុពី៦ឆ្នាំ ឬយ៉ាងទាប៧០ខែ នៅក្នុងភូមិនៃផែនទីសិក្សា (សរុប)
  indicator2: number | ''; // ចំនួនកុមារអាយុពី៦ឆ្នាំ ឬយ៉ាងទាប៧០ខែ នៅក្នុងភូមិនៃផែនទីសិក្សា (ស្រី)
  indicator3: number | ''; // ចំនួនថ្នាក់រៀនពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣ សរុបទាំងអស់នៅក្នុងសាលារៀន
  indicator4: number | ''; // ចំនួនថ្នាក់រៀនពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦ សរុបទាំងអស់នៅក្នុងសាលារៀន
  indicator5: number | ''; // ចំនួនគ្រូទទួលបន្ទុកថ្នាក់ជាក់ស្ដែងពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣
  indicator6: number | ''; // ចំនួនគ្រូទទួលបន្ទុកថ្នាក់ជាក់ស្ដែងពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦
  indicator7: number | ''; // ចំនួនថ្នាក់រៀនដែលមានសិស្សតិចជាង ឬស្មើ៤៥នាក់ក្នុងមួយថ្នាក់ ពីថ្នាក់ទី១ ដល់ថ្នាក់ទី៣
  indicator8: number | ''; // ចំនួនថ្នាក់រៀនដែលមានសិស្សតិចជាង ឬស្មើ៤០នាក់ក្នុងមួយថ្នាក់ ពីថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦
  indicator9: number | ''; // ចំនួនសិស្សសរុបនៃថ្នាក់ទី១ ដល់ ថ្នាក់ទី៣
  indicator10: number | ''; // ចំនួនសិស្សដែលរៀនថ្នាក់ទី១ ដល់ថ្នាក់ទី៣ ដែលបានទទួលសៀវភៅសិក្សាគោល ៣ក្បាល
  indicator11: number | ''; // ចំនួនសិស្សសរុបនៃថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦
  indicator12: number | ''; // ចំនួនសិស្សដែលរៀនថ្នាក់ទី៤ ដល់ថ្នាក់ទី៦ ដែលបានទទួលសៀវភៅសិក្សាគោល ៤ក្បាល
  indicator13: number | ''; // ចំនួនសិស្សដែលបានទទួលការបង្រៀនរយៈពេល២១១ ថ្ងៃពេញ
  indicator14: number | ''; // ចំនួនសិស្សប្រុស សរុប នៅក្នុងសាលា
  indicator15: number | ''; // ចំនួនសិស្សស្រីសរុប នៅក្នុងសាលា
  indicator16: number | ''; // ចំនួនសិស្សសរុបដែលរៀនត្រួតថ្នាក់
  indicator17: number | ''; // ចំនួនសិស្សដែលរៀនថ្នាក់ទី១ កាលពី ៦ឆ្នាំមុន
  indicator18: number | ''; // ចំនួនសិស្សដែលរៀនថ្នាក់ទី៦
  indicator19: number | ''; // ចំនួនកុមារដែលមានអាយុ១១ឆ្នាំ
  indicator20: number | ''; // ចំនួនសិស្សថ្មីដែលចូលរៀនថ្នាក់ទី១
  indicator21: number | ''; // ចំនួនកិច្ចប្រជុំរបស់គណៈកម្មការគ្រប់គ្រងសាលាដែលបានរៀបចំក្នុងមួយឆ្នាំ
  indicator22: 'yes' | 'no' | ''; // កិច្ចសន្យាជាមួយអ្នកលក់ចំណីអាហារ ស្តីពីលើកកម្ពស់សុខភាព
  indicator23: 'yes' | 'no' | ''; // បិទផ្សាយគោលការណ៍ណែនាំស្តីពីការលើកកម្ពស់សុខភាព
}

export interface IndicatorDefinition {
  id: number;
  key: IndicatorKey;
  name: string;
  subLabel?: string;
  instruction: string;
  type: 'number' | 'boolean';
  category: 'population' | 'classes' | 'teachers' | 'students' | 'textbooks' | 'operations';
}

export interface ValidationIssue {
  type: 'error' | 'warning' | 'info';
  message: string;
  relatedIndicators?: number[];
}
