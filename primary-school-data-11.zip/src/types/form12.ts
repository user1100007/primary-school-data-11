import { SchoolMetadata } from './form11';

export type Form12Key =
  | 'income1'
  | 'income2'
  | 'income3'
  | 'income4'
  | 'expense5'
  | 'expense6'
  | 'expense7';

export interface Form12ItemDefinition {
  id: number;
  key: Form12Key;
  section: 'income' | 'expense';
  name: string;
  description: string;
}

export interface Form12Data {
  metadata: SchoolMetadata;
  income1: number | ''; // 1. ថវិការដ្ឋ
  income2: number | ''; // 2. ថវិកាដៃគូ
  income3: number | ''; // 3. ថវិកាសហគមន៍
  income4: number | ''; // 4. ថវិកាផ្សេងៗ
  expense5: number | ''; // 5. ប្រាក់បៀវត្ស និងប្រាក់ឧបត្ថម្ភសម្រាប់គ្រូបង្រៀន
  expense6: number | ''; // 6. គាំទ្រកិច្ចដំណើរការសាលារៀន
  expense7: number | ''; // 7. កែលម្អគុណភាពនៃការអប់រំ
}
